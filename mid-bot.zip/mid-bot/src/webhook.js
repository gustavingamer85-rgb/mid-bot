'use strict';
const crypto = require('crypto');
const express = require('express');
const { config } = require('./db');
const mid = require('./mid');

const hmacHex = (secret, ...parts) => {
  const h = crypto.createHmac('sha256', secret);
  for (const p of parts) h.update(p);
  return h.digest();
};

function safeEqual(a, b) {
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** EclipsePay: v1=HMAC(secret, `${ts}.${eventId}.${rawBody}`) */
function verifyEclipse(secret, headers, raw) {
  const id = headers['x-eclipse-event-id'];
  const ts = headers['x-eclipse-timestamp'];
  const sig = headers['x-eclipse-signature'];
  if (!id || !ts || !/^v1=[0-9a-f]{64}$/.test(sig || '')) return null;
  if (Math.abs(Date.now() / 1000 - Number(ts)) > 300) return null;
  const expected = hmacHex(secret, `${ts}.${id}.`, raw);
  if (!safeEqual(expected, Buffer.from(sig.slice(3), 'hex'))) return null;
  const event = JSON.parse(raw.toString('utf8'));
  return event.id === id ? event : null;
}

/** PurinCash: hex(HMAC(secret, rawBody)) em X-Webhook-Signature */
function verifyPurin(secret, headers, raw) {
  const sig = String(headers['x-webhook-signature'] || '');
  if (!/^[0-9a-f]{64}$/i.test(sig)) return null;
  if (!safeEqual(hmacHex(secret, raw), Buffer.from(sig, 'hex'))) return null;
  return JSON.parse(raw.toString('utf8'));
}

function createApp() {
  const app = express();
  const raw = express.raw({ type: '*/*', limit: '256kb' });

  app.get('/', (_req, res) => res.send('MID bot online'));

  app.post('/webhook/eclipsepay', raw, (req, res) => {
    const secret = config.eclipsepay.webhookSecret;
    if (!secret) return res.status(503).send('webhook secret não configurado');
    let event;
    try { event = verifyEclipse(secret, req.headers, req.body); } catch { event = null; }
    if (!event) return res.status(401).send('assinatura inválida');

    if (event.type === 'webhook.endpoint_verification') {
      return res.json({ challenge: event.data?.challenge });
    }
    res.sendStatus(200);
    // O webhook é só um "gatilho": o estado real sempre é reconfirmado na API do gateway.
    const opId = event.data?.operationId;
    if (!opId) return;
    if (String(event.type).startsWith('charge.')) mid.checkChargeById(opId).catch((e) => console.error('[wh eclipse]', e.message));
    else if (String(event.type).startsWith('payout.')) mid.checkPayoutById(opId).catch((e) => console.error('[wh eclipse]', e.message));
  });

  app.post('/webhook/purincash', raw, (req, res) => {
    const secret = config.purincash.webhookSecret;
    if (!secret) return res.status(503).send('webhook secret não configurado');
    let event;
    try { event = verifyPurin(secret, req.headers, req.body); } catch { event = null; }
    if (!event) return res.status(401).send('assinatura inválida');
    res.json({ ok: true });
    if (event.paymentId) mid.checkChargeById(event.paymentId).catch((e) => console.error('[wh purin]', e.message));
  });

  return app;
}

function startWebhookServer(port) {
  const app = createApp();
  return app.listen(port, () => console.log(`[webhook] escutando na porta ${port}`));
}

module.exports = { startWebhookServer, createApp, verifyEclipse, verifyPurin };

'use strict';
// Gera a imagem do perfil (PNG) com @napi-rs/canvas.
const FONT = '"Segoe UI", "Helvetica Neue", Arial, "DejaVu Sans", sans-serif';
const PURPLE = '#a855f7';

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function star(ctx, cx, cy, R, r) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const rad = i % 2 === 0 ? R : r;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    ctx.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
  }
  ctx.closePath();
}

function lock(ctx, cx, cy, color) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.arc(cx, cy - 3, 6.5, Math.PI, 0);
  ctx.stroke();
  ctx.fillStyle = color;
  rr(ctx, cx - 9.5, cy - 3, 19, 15, 3.5);
  ctx.fill();
}

function moon(ctx, cx, cy, r, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#0d0b16'; // cor do fundo: recorta a lua em "crescente"
  ctx.beginPath();
  ctx.arc(cx + r * 0.5, cy - r * 0.3, r * 0.85, 0, Math.PI * 2);
  ctx.fill();
}

function wrap(ctx, text, maxW) {
  const words = String(text).split(' ');
  const lines = [];
  let cur = '';
  for (const w of words) {
    const t = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

/**
 * data = { name, username, avatarBuffer?, tierName, tierColor,
 *          stats: [{label, value, accent?}] (6), emblems: [{label, color, unlocked}] }
 */
async function renderProfileCard(data) {
  const { createCanvas, loadImage } = require('@napi-rs/canvas');
  const W = 900;
  const PAD = 28;
  const emblemCount = Math.max(1, data.emblems.length);
  const H = 566;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // fundo
  ctx.fillStyle = '#0d0b16';
  rr(ctx, 0, 0, W, H, 22);
  ctx.fill();
  const glow = ctx.createRadialGradient(W - 120, H - 40, 10, W - 120, H - 40, 380);
  glow.addColorStop(0, 'rgba(120,60,200,0.22)');
  glow.addColorStop(1, 'rgba(120,60,200,0)');
  ctx.save();
  rr(ctx, 0, 0, W, H, 22);
  ctx.clip();
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
  ctx.strokeStyle = '#1f1a30';
  ctx.lineWidth = 2;
  rr(ctx, 1, 1, W - 2, H - 2, 22);
  ctx.stroke();

  // cabeçalho
  const ax = PAD + 56;
  const ay = PAD + 62;
  ctx.fillStyle = PURPLE;
  ctx.beginPath();
  ctx.arc(ax, ay, 56, 0, Math.PI * 2);
  ctx.fill();
  ctx.save();
  ctx.beginPath();
  ctx.arc(ax, ay, 51, 0, Math.PI * 2);
  ctx.clip();
  let drawn = false;
  if (data.avatarBuffer) {
    try { ctx.drawImage(await loadImage(data.avatarBuffer), ax - 51, ay - 51, 102, 102); drawn = true; } catch { /* usa placeholder */ }
  }
  if (!drawn) {
    ctx.fillStyle = '#2a2140';
    ctx.fillRect(ax - 51, ay - 51, 102, 102);
    ctx.fillStyle = '#cbb8f5';
    ctx.font = `bold 46px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.fillText(String(data.name || '?').slice(0, 1).toUpperCase(), ax, ay + 16);
  }
  ctx.restore();

  const tx = PAD + 140;
  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 30px ${FONT}`;
  let name = String(data.name || '');
  while (ctx.measureText(name).width > 520 && name.length > 3) name = name.slice(0, -2);
  if (name !== data.name) name += '…';
  ctx.fillText(name, tx, ay - 18);
  ctx.fillStyle = '#8b8a9b';
  ctx.font = `17px ${FONT}`;
  ctx.fillText(`@${data.username}`, tx, ay + 8);
  moon(ctx, tx + 11, ay + 40, 11, data.tierColor);
  ctx.fillStyle = data.tierColor;
  ctx.font = `bold 19px ${FONT}`;
  ctx.fillText(`- ${data.tierName}`, tx + 30, ay + 47);

  ctx.fillStyle = '#6d6b7d';
  ctx.font = `bold 11px ${FONT}`;
  ctx.textAlign = 'right';
  ctx.fillText('P E R F I L   M M', W - PAD - 4, PAD + 14);
  ctx.textAlign = 'left';

  // seção informações
  const section = (y, title) => {
    ctx.fillStyle = PURPLE;
    ctx.fillRect(PAD, y - 15, 4, 20);
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold 19px ${FONT}`;
    ctx.fillText(title, PAD + 14, y);
  };
  section(200, 'Informações');

  const gap = 14;
  const tw = (W - PAD * 2 - gap * 2) / 3;
  const th = 80;
  data.stats.forEach((st, i) => {
    const x = PAD + (i % 3) * (tw + gap);
    const y = 222 + Math.floor(i / 3) * (th + gap);
    ctx.fillStyle = '#14111f';
    rr(ctx, x, y, tw, th, 14);
    ctx.fill();
    ctx.strokeStyle = '#231e35';
    ctx.lineWidth = 1.5;
    rr(ctx, x, y, tw, th, 14);
    ctx.stroke();
    ctx.fillStyle = '#8b8a9b';
    ctx.font = `bold 14px ${FONT}`;
    ctx.fillText(st.label, x + 18, y + 29);
    ctx.fillStyle = st.accent ? PURPLE : '#ffffff';
    ctx.font = `bold 26px ${FONT}`;
    ctx.fillText(st.value, x + 18, y + 61);
  });

  // emblemas
  section(432, 'Emblemas');
  const eg = 10;
  const ew = (W - PAD * 2 - eg * (emblemCount - 1)) / emblemCount;
  const eh = 98;
  const ey = 452;
  data.emblems.forEach((em, i) => {
    const x = PAD + i * (ew + eg);
    ctx.fillStyle = em.unlocked ? '#17122a' : '#12101c';
    rr(ctx, x, ey, ew, eh, 14);
    ctx.fill();
    ctx.strokeStyle = em.unlocked ? em.color : '#231e35';
    ctx.lineWidth = em.unlocked ? 2 : 1.5;
    rr(ctx, x, ey, ew, eh, 14);
    ctx.stroke();
    const cx = x + ew / 2;
    const cy = ey + 32;
    ctx.fillStyle = em.unlocked ? em.color : '#1b1727';
    ctx.beginPath();
    ctx.arc(cx, cy, 20, 0, Math.PI * 2);
    ctx.fill();
    if (em.unlocked) {
      ctx.fillStyle = '#ffffff';
      star(ctx, cx, cy + 1, 11, 4.6);
      ctx.fill();
    } else {
      lock(ctx, cx, cy, '#6b6880');
    }
    ctx.fillStyle = em.unlocked ? '#e7e3f5' : '#7c7a8c';
    ctx.font = `bold 11px ${FONT}`;
    ctx.textAlign = 'center';
    const lines = wrap(ctx, em.label, ew - 12);
    lines.forEach((l, k) => ctx.fillText(l, cx, ey + 72 + k * 14));
    ctx.textAlign = 'left';
  });

  return canvas.toBuffer('image/png');
}

module.exports = { renderProfileCard };

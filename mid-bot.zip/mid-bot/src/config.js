'use strict';
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  StringSelectMenuBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType, MessageFlags,
} = require('discord.js');
const { config, saveConfig } = require('./db');
const { getGateway } = require('./gateways');
const U = require('./utils');

const EPH = MessageFlags.Ephemeral;
const row = (...c) => new ActionRowBuilder().addComponents(...c);
const btn = (id, label, style = ButtonStyle.Secondary, emoji) => {
  const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  if (emoji) b.setEmoji(emoji);
  return b;
};
const PAYER = { buyer: 'Comprador', seller: 'Vendedor', split: 'Dividida' };
const GW_NAME = { eclipsepay: 'EclipsePay', purincash: 'PurinCash' };
const ch = (id) => (id ? `<#${id}>` : '`não definido`');

// ======================================================================
// Views
// ======================================================================
function mainView(notice) {
  const baseUrl = config.publicUrl ? config.publicUrl.replace(/\/$/, '') : '';
  const embed = new EmbedBuilder()
    .setColor(config.enabled ? 0x5865f2 : 0x4f545c)
    .setTitle('⚙️ Configuração do Middleman')
    .setDescription('Use os controles abaixo. Tudo é salvo na hora e as chaves ficam visíveis só para você (mensagem efêmera).')
    .addFields(
      { name: 'Sistema', value: config.enabled ? '🟢 Ligado' : '🔴 Desligado', inline: true },
      { name: 'Gateway ativo', value: `**${GW_NAME[config.gateway]}**`, inline: true },
      { name: '​', value: '​', inline: true },
      { name: 'EclipsePay', value: `API: ${U.mask(config.eclipsepay.apiKey)}\nWebhook secret: ${config.eclipsepay.webhookSecret ? '✅' : '❌'}`, inline: true },
      { name: 'PurinCash', value: `API: ${U.mask(config.purincash.apiKey)}\nWebhook secret: ${config.purincash.webhookSecret ? '✅' : '❌'}\nTurbo: ${config.purincash.turbo ? 'sim' : 'não'}`, inline: true },
      { name: '​', value: '​', inline: true },
      { name: 'Taxa do MID', value: `${config.feePercent}% (mín. ${U.brl(config.feeMinCents)})\nPaga por: **${PAYER[config.feePayer]}**`, inline: true },
      { name: 'Limites do negócio', value: `${U.brl(config.minCents)} a ${U.brl(config.maxCents)}`, inline: true },
      { name: 'Prazos', value: `PIX expira em ${config.paymentExpiryMin} min\nInativo cancela em ${config.idleCancelMin} min\nMáx. ${config.maxOpenDeals} abertas/usuário`, inline: true },
      { name: 'Tickets', value: `Categoria: ${ch(config.ticketCategoryId)}\nLogs: ${ch(config.logChannelId)}\nStaff: ${config.staffRoleId ? `<@&${config.staffRoleId}>` : '`não definido`'}`, inline: true },
      { name: 'Painel', value: config.panelChannelId ? `Enviado em ${ch(config.panelChannelId)}` : '`ainda não enviado`', inline: true },
      { name: 'Webhooks', value: baseUrl ? `\`${baseUrl}/webhook/eclipsepay\`\n\`${baseUrl}/webhook/purincash\`` : 'Sem URL pública (o bot confere pagamentos automaticamente a cada 20s).', inline: false },
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId('cfg:gw')
    .setPlaceholder('Escolha o gateway ativo')
    .addOptions(
      { label: 'PurinCash', value: 'purincash', default: config.gateway === 'purincash', emoji: '🟣' },
      { label: 'EclipsePay', value: 'eclipsepay', default: config.gateway === 'eclipsepay', emoji: '🌙' },
    );

  return {
    content: notice || '',
    embeds: [embed],
    components: [
      row(select),
      row(
        btn('cfg:m:eclipsepay', 'Chaves EclipsePay', ButtonStyle.Primary, '🔑'),
        btn('cfg:m:purincash', 'Chaves PurinCash', ButtonStyle.Primary, '🔑'),
        btn('cfg:m:fees', 'Taxas e limites', ButtonStyle.Secondary, '💸'),
        btn('cfg:m:misc', 'Prazos e webhook', ButtonStyle.Secondary, '⏱️'),
      ),
      row(
        btn('cfg:view:chan', 'Canais e cargos', ButtonStyle.Secondary, '📁'),
        btn('cfg:m:panel', 'Aparência do painel', ButtonStyle.Secondary, '🎨'),
        btn('cfg:view:send', 'Enviar painel', ButtonStyle.Success, '📤'),
      ),
      row(
        btn('cfg:test', 'Testar gateways', ButtonStyle.Secondary, '🧪'),
        btn('cfg:toggle', config.enabled ? 'Desligar sistema' : 'Ligar sistema', config.enabled ? ButtonStyle.Danger : ButtonStyle.Success, config.enabled ? '⏹️' : '▶️'),
      ),
    ],
  };
}

function chanView() {
  const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('📁 Canais e cargos')
    .setDescription(
      `**Categoria dos tickets:** ${ch(config.ticketCategoryId)}\n` +
      `**Canal de logs:** ${ch(config.logChannelId)}\n` +
      `**Cargo da staff (middlemen):** ${config.staffRoleId ? `<@&${config.staffRoleId}>` : '`não definido`'}`,
    );
  return {
    content: '', embeds: [embed],
    components: [
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:cat').setPlaceholder('Categoria onde os tickets serão criados').setChannelTypes(ChannelType.GuildCategory)),
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:log').setPlaceholder('Canal de logs e transcrições').setChannelTypes(ChannelType.GuildText)),
      row(new RoleSelectMenuBuilder().setCustomId('cfg:staff').setPlaceholder('Cargo da staff que resolve disputas')),
      row(btn('cfg:view:main', 'Voltar', ButtonStyle.Secondary, '⬅️')),
    ],
  };
}

function sendView() {
  return {
    content: '', embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('📤 Enviar painel de MID').setDescription('Escolha o canal onde o painel com os botões **Sou comprador / Sou vendedor** será publicado.')],
    components: [
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:panelch').setPlaceholder('Canal do painel').setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
      row(btn('cfg:view:main', 'Voltar', ButtonStyle.Secondary, '⬅️')),
    ],
  };
}

// ======================================================================
// Modais
// ======================================================================
function modal(id, title, fields) {
  const m = new ModalBuilder().setCustomId(id).setTitle(title);
  for (const f of fields) {
    const t = new TextInputBuilder().setCustomId(f.id).setLabel(f.label).setStyle(f.long ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(Boolean(f.required));
    if (f.placeholder) t.setPlaceholder(f.placeholder);
    if (f.value) t.setValue(String(f.value).slice(0, 4000));
    m.addComponents(row(t));
  }
  return m;
}

function buildModal(name) {
  switch (name) {
    case 'eclipsepay':
      return modal('cfg:ms:eclipsepay', 'Chaves da EclipsePay', [
        { id: 'apiKey', label: 'API Key (Bearer)', placeholder: 'Deixe vazio para manter a atual' },
        { id: 'webhookSecret', label: 'Webhook secret (opcional)', placeholder: 'Mostrado ao criar o webhook no painel' },
      ]);
    case 'purincash':
      return modal('cfg:ms:purincash', 'Chaves da PurinCash', [
        { id: 'apiKey', label: 'API Key (ps_live_... / ps_test_...)', placeholder: 'Deixe vazio para manter a atual' },
        { id: 'webhookSecret', label: 'Webhook secret (opcional)', placeholder: 'Painel > Equipe & API > Developer API' },
        { id: 'turbo', label: 'Saque PIX instantâneo (turbo)? sim/não', value: config.purincash.turbo ? 'sim' : 'não', required: true },
      ]);
    case 'fees':
      return modal('cfg:ms:fees', 'Taxas e limites', [
        { id: 'pct', label: 'Taxa do MID (%)', value: config.feePercent, required: true },
        { id: 'min', label: 'Taxa mínima (R$)', value: (config.feeMinCents / 100).toFixed(2).replace('.', ','), required: true },
        { id: 'payer', label: 'Quem paga: comprador, vendedor ou dividir', value: { buyer: 'comprador', seller: 'vendedor', split: 'dividir' }[config.feePayer], required: true },
        { id: 'vmin', label: 'Valor mínimo do negócio (R$)', value: (config.minCents / 100).toFixed(2).replace('.', ','), required: true },
        { id: 'vmax', label: 'Valor máximo do negócio (R$)', value: (config.maxCents / 100).toFixed(2).replace('.', ','), required: true },
      ]);
    case 'misc':
      return modal('cfg:ms:misc', 'Prazos e webhook', [
        { id: 'url', label: 'URL pública do bot (https://...)', value: config.publicUrl, placeholder: 'Opcional. Ex: https://meubot.exemplo.com' },
        { id: 'expiry', label: 'PIX expira em (minutos)', value: config.paymentExpiryMin, required: true },
        { id: 'idle', label: 'Cancelar inativas após (minutos)', value: config.idleCancelMin, required: true },
        { id: 'open', label: 'Máx. negociações abertas por usuário', value: config.maxOpenDeals, required: true },
      ]);
    case 'panel':
      return modal('cfg:ms:panel', 'Aparência do painel', [
        { id: 'title', label: 'Título', value: config.panel.title, required: true },
        { id: 'desc', label: 'Descrição', value: config.panel.description, long: true, required: true },
        { id: 'color', label: 'Cor (hex)', value: config.panel.color, required: true },
        { id: 'image', label: 'URL da imagem/banner (opcional)', value: config.panel.image },
      ]);
    default:
      return null;
  }
}

function applyModal(name, f) {
  const get = (id) => (f.getTextInputValue(id) || '').trim();
  switch (name) {
    case 'eclipsepay':
      if (get('apiKey')) config.eclipsepay.apiKey = get('apiKey');
      if (get('webhookSecret')) config.eclipsepay.webhookSecret = get('webhookSecret');
      return 'Chaves da EclipsePay salvas.';
    case 'purincash':
      if (get('apiKey')) config.purincash.apiKey = get('apiKey');
      if (get('webhookSecret')) config.purincash.webhookSecret = get('webhookSecret');
      config.purincash.turbo = /^(s|sim|true|1|yes)/i.test(get('turbo'));
      return 'Chaves da PurinCash salvas.';
    case 'fees': {
      const pct = U.parseNumber(get('pct'));
      const min = U.parseMoney(get('min'));
      const vmin = U.parseMoney(get('vmin'));
      const vmax = U.parseMoney(get('vmax'));
      const payer = { comprador: 'buyer', vendedor: 'seller', dividir: 'split', dividida: 'split' }[get('payer').toLowerCase()];
      if (!(pct >= 0 && pct <= 50)) throw new Error('Taxa (%) deve estar entre 0 e 50.');
      if (!Number.isFinite(min) || !Number.isFinite(vmin) || !Number.isFinite(vmax)) throw new Error('Valores em R$ inválidos.');
      if (!payer) throw new Error('Quem paga: use comprador, vendedor ou dividir.');
      if (vmin < 80 || vmax < vmin) throw new Error('Limites inválidos (mínimo R$ 0,80 e máximo ≥ mínimo).');
      Object.assign(config, { feePercent: pct, feeMinCents: min, feePayer: payer, minCents: vmin, maxCents: vmax });
      return 'Taxas e limites salvos.';
    }
    case 'misc': {
      const url = get('url');
      if (url && !/^https:\/\/[^\s]+$/i.test(url)) throw new Error('A URL pública deve começar com https://');
      const expiry = Number(get('expiry'));
      const idle = Number(get('idle'));
      const open = Number(get('open'));
      if (!(expiry >= 2 && expiry <= 1440)) throw new Error('Expiração do PIX: 2 a 1440 minutos.');
      if (!(idle >= 5 && idle <= 10080)) throw new Error('Inatividade: 5 a 10080 minutos.');
      if (!(open >= 1 && open <= 20)) throw new Error('Negociações abertas: 1 a 20.');
      Object.assign(config, { publicUrl: url, paymentExpiryMin: Math.round(expiry), idleCancelMin: Math.round(idle), maxOpenDeals: Math.round(open) });
      return 'Prazos e webhook salvos.';
    }
    case 'panel': {
      const color = get('color');
      if (!/^#?[0-9a-f]{6}$/i.test(color)) throw new Error('Cor inválida. Use hex, ex: #5865F2');
      const image = get('image');
      if (image && !/^https?:\/\//i.test(image)) throw new Error('A imagem deve ser uma URL http(s).');
      config.panel = { title: get('title').slice(0, 250), description: get('desc').slice(0, 3500), color: color.startsWith('#') ? color : `#${color}`, image };
      return 'Aparência do painel salva. Reenvie o painel para atualizar.';
    }
    default:
      throw new Error('Modal desconhecido.');
  }
}

// ======================================================================
// Painel público
// ======================================================================
function buildPanel() {
  const e = new EmbedBuilder()
    .setColor(parseInt(config.panel.color.replace('#', ''), 16) || 0x5865f2)
    .setTitle(config.panel.title)
    .setDescription(config.panel.description)
    .setFooter({ text: `Taxa: ${config.feePercent}% (mín. ${U.brl(config.feeMinCents)}) • Pagamento via PIX` });
  if (config.panel.image) e.setImage(config.panel.image);
  return {
    embeds: [e],
    components: [row(
      btn('mid:start:buyer', 'Sou o comprador', ButtonStyle.Success, '🛒'),
      btn('mid:start:seller', 'Sou o vendedor', ButtonStyle.Primary, '💼'),
    )],
  };
}

// ======================================================================
// Handlers
// ======================================================================
async function showPanel(interaction) {
  if (!U.isAdmin(interaction)) return interaction.reply({ content: '⛔ Apenas administradores podem usar este comando.', flags: EPH });
  return interaction.reply({ ...mainView(), flags: EPH });
}

async function handle(interaction) {
  if (!U.isAdmin(interaction)) return interaction.reply({ content: '⛔ Apenas administradores.', flags: EPH });
  const id = interaction.customId;

  try {
    // --- modal submit ---
    if (interaction.isModalSubmit()) {
      const name = id.split(':')[2];
      let notice;
      try { notice = applyModal(name, interaction.fields); } catch (e) { return interaction.reply({ content: `❌ ${e.message}`, flags: EPH }); }
      saveConfig();
      // Testa a chave recém-salva (sem exibir segredo)
      let extra = '';
      if ((name === 'eclipsepay' || name === 'purincash') && config[name].apiKey) {
        await interaction.deferReply({ flags: EPH });
        try {
          const b = await getGateway(name).getBalance();
          extra = `\n🟢 Conexão OK • saldo disponível: **${U.brl(b.availableCents ?? 0)}**`;
        } catch (e) { extra = `\n🔴 Não consegui validar a chave: \`${e.message}\``; }
        return interaction.editReply({ content: `✅ ${notice}${extra}` });
      }
      return interaction.reply({ content: `✅ ${notice}`, flags: EPH });
    }

    // --- botões ---
    if (interaction.isButton()) {
      if (id.startsWith('cfg:m:')) return interaction.showModal(buildModal(id.split(':')[2]));
      if (id === 'cfg:view:main') return interaction.update(mainView());
      if (id === 'cfg:view:chan') return interaction.update(chanView());
      if (id === 'cfg:view:send') return interaction.update(sendView());
      if (id === 'cfg:toggle') {
        config.enabled = !config.enabled;
        saveConfig();
        return interaction.update(mainView(config.enabled ? '🟢 Sistema ligado.' : '🔴 Sistema desligado: novas negociações estão bloqueadas.'));
      }
      if (id === 'cfg:test') {
        await interaction.deferReply({ flags: EPH });
        const lines = [];
        for (const name of ['eclipsepay', 'purincash']) {
          if (!config[name].apiKey) { lines.push(`⚪ **${GW_NAME[name]}**: sem chave`); continue; }
          try {
            const b = await getGateway(name).getBalance();
            lines.push(`🟢 **${GW_NAME[name]}**: OK • saldo ${U.brl(b.balanceCents ?? 0)} • disponível ${U.brl(b.availableCents ?? 0)}`);
          } catch (e) { lines.push(`🔴 **${GW_NAME[name]}**: ${e.message}`); }
        }
        return interaction.editReply(lines.join('\n'));
      }
    }

    // --- selects ---
    if (interaction.isStringSelectMenu() && id === 'cfg:gw') {
      const gw = interaction.values[0];
      if (!config[gw].apiKey) return interaction.update(mainView(`⚠️ Configure a chave da ${GW_NAME[gw]} antes de ativá-la.`));
      config.gateway = gw;
      saveConfig();
      return interaction.update(mainView(`✅ Gateway ativo: **${GW_NAME[gw]}**. Negociações já em andamento continuam no gateway em que foram cobradas.`));
    }
    if (interaction.isChannelSelectMenu()) {
      const chId = interaction.values[0];
      if (id === 'cfg:cat') { config.ticketCategoryId = chId; saveConfig(); return interaction.update(chanView()); }
      if (id === 'cfg:log') { config.logChannelId = chId; saveConfig(); return interaction.update(chanView()); }
      if (id === 'cfg:panelch') {
        const target = await interaction.guild.channels.fetch(chId);
        try {
          const msg = await target.send(buildPanel());
          config.panelChannelId = chId;
          config.panelMessageId = msg.id;
          saveConfig();
        } catch (e) {
          return interaction.update({ ...sendView(), content: `❌ Não consegui enviar em ${target}: ${e.message}` });
        }
        return interaction.update(mainView(`✅ Painel enviado em ${target}.`));
      }
    }
    if (interaction.isRoleSelectMenu() && id === 'cfg:staff') {
      config.staffRoleId = interaction.values[0];
      saveConfig();
      return interaction.update(chanView());
    }
  } catch (e) {
    console.error('[config]', e);
    const payload = { content: `❌ Erro: ${e.message}`, flags: EPH };
    if (interaction.deferred || interaction.replied) return interaction.followUp(payload).catch(() => {});
    return interaction.reply(payload).catch(() => {});
  }
}

module.exports = { showPanel, handle, mainView, chanView, sendView, buildPanel, buildModal };

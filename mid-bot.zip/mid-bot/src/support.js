'use strict';
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder, UserSelectMenuBuilder, ChannelType, PermissionFlagsBits,
  AttachmentBuilder, MessageFlags, SlashCommandBuilder,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder,
} = require('discord.js');
const { config, saveConfig, tickets } = require('./db');
const U = require('./utils');
const { audit } = require('./moderation');

const EPH = MessageFlags.Ephemeral;
const P = PermissionFlagsBits;
const { Primary, Secondary, Success, Danger } = ButtonStyle;
const TZ = 'America/Sao_Paulo';
const MAX_CATEGORIES = 5;

const sup = () => config.support;
const row = (...c) => new ActionRowBuilder().addComponents(...c);
const btn = (id, label, style = Secondary, emoji) => {
  const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  if (emoji) b.setEmoji(emoji);
  return b;
};
const ch = (id) => (id ? `<#${id}>` : '`não definido`');
const pad = (id) => String(id).padStart(4, '0');
const cut = (s, n = 1000) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));
const staffRoleId = () => sup().staffRoleId || config.staffRoleId || '';
const staffPing = () => (staffRoleId() ? `<@&${staffRoleId()}>` : '');
const accent = () => parseInt(String(sup().panel.color).replace('#', ''), 16) || 0x5865f2;

const isSupportStaff = (i) =>
  U.isAdmin(i) ||
  Boolean(staffRoleId() && i.member?.roles?.cache?.has(staffRoleId())) ||
  Boolean(i.memberPermissions?.has(P.ManageChannels));

// ======================================================================
// Categorias
// ======================================================================
const slugify = (s) =>
  String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || 'ticket';

const PICTO = String.raw`\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?`;
const EMOJI_OK = new RegExp(String.raw`^(?:<a?:\w{2,32}:\d{15,25}>|${PICTO}(?:\u200D${PICTO})*|[\u{1F1E6}-\u{1F1FF}]{2}|[0-9#*]\uFE0F?\u20E3)$`, 'u');

/** "emoji | nome | descrição" (uma por linha). Só o nome também vale. */
function parseCategories(text) {
  const out = [];
  for (const raw of String(text || '').split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    const parts = line.split('|').map((p) => p.trim());
    let emoji = ''; let name; let description = '';
    if (parts.length === 1) [name] = parts;
    else [emoji, name, description = ''] = parts;
    if (!name) throw new Error(`Linha sem nome: "${line}". Use: emoji | nome | descrição`);
    if (emoji && !EMOJI_OK.test(emoji)) throw new Error(`Emoji inválido na linha "${line}". Use um emoji padrão (ex: 🚨) ou deixe vazio.`);
    let key = slugify(name);
    for (let n = 2; out.some((c) => c.key === key); n++) key = `${slugify(name).slice(0, 17)}-${n}`;
    out.push({ key, emoji, name: name.slice(0, 80), description: description.slice(0, 100) });
  }
  if (!out.length) throw new Error('Informe pelo menos uma categoria.');
  if (out.length > MAX_CATEGORIES) throw new Error(`No máximo ${MAX_CATEGORIES} categorias.`);
  return out;
}
const categoriesToText = (cats) => cats.map((c) => `${c.emoji} | ${c.name} | ${c.description}`).join('\n');
const findCategory = (key) => sup().categories.find((c) => c.key === key);

// ======================================================================
// Painel público (enviado com /painel-ticket)
// ======================================================================
function buildPanel() {
  const s = sup();
  const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
  const text = (c) => new TextDisplayBuilder().setContent(c);
  const container = new ContainerBuilder()
    .setAccentColor(accent())
    .addTextDisplayComponents(text(`## ${s.panel.title}`))
    .addSeparatorComponents(sep());
  if (s.panel.image) {
    container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(s.panel.image)));
    container.addSeparatorComponents(sep());
  }
  const list = s.categories.map((c) => `${c.emoji ? `${c.emoji} ` : ''}**${c.name}**${c.description ? ` — ${c.description}` : ''}`).join('\n');
  container.addTextDisplayComponents(text(`${s.panel.description}\n\n${list}`)).addSeparatorComponents(sep());
  container.addActionRowComponents(row(...s.categories.slice(0, MAX_CATEGORIES).map((c) => btn(`tk:open:${c.key}`, c.name.slice(0, 80), Primary, c.emoji || undefined))));
  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

async function refreshPanel(client) {
  const s = sup();
  if (!s.panelChannelId || !s.panelMessageId) return false;
  try {
    const c = await client.channels.fetch(s.panelChannelId);
    const msg = await c.messages.fetch(s.panelMessageId);
    await msg.edit(buildPanel());
    return true;
  } catch { return false; }
}

const commands = [
  new SlashCommandBuilder()
    .setName('painel-ticket')
    .setDescription('Envia o painel de tickets de suporte (somente administradores)')
    .setDefaultMemberPermissions(P.Administrator)
    .setDMPermission(false)
    .addChannelOption((o) => o.setName('canal').setDescription('Canal onde o painel será enviado (padrão: o atual)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .toJSON(),
];

async function sendPanelCommand(i) {
  if (!U.isAdmin(i)) return i.reply({ content: '⛔ Apenas administradores podem usar este comando.', flags: EPH });
  await i.deferReply({ flags: EPH });
  const target = i.options.getChannel('canal') || i.channel;
  let msg;
  try {
    msg = await target.send(buildPanel());
  } catch (e) {
    return i.editReply(`❌ Não consegui enviar o painel em ${target}: ${e.message}`);
  }
  sup().panelChannelId = target.id;
  sup().panelMessageId = msg.id;
  saveConfig();
  const logged = await audit(i, {
    title: '🎫 Painel de tickets enviado', color: 0x5865f2,
    fields: [{ name: 'Canal', value: `${target}`, inline: true }, { name: 'Mensagem', value: `[Ir para o painel](${msg.url})`, inline: true }],
  });
  const warns = [];
  if (!sup().categoryId) warns.push('• Defina a **categoria dos tickets** em /config → Moderação e suporte.');
  if (!staffRoleId()) warns.push('• Defina o **cargo atendente** em /config → Moderação e suporte.');
  if (!logged) warns.push('• O canal de auditoria não está configurado.');
  return i.editReply(`✅ Painel de tickets enviado em ${target}.${warns.length ? `\n\n⚠️ Pendências:\n${warns.join('\n')}` : ''}`);
}

// ======================================================================
// Ticket: render, logs e utilidades
// ======================================================================
function renderTicket(t) {
  const embed = new EmbedBuilder()
    .setColor(t.claimedBy ? 0x57f287 : 0x5865f2)
    .setTitle(`🎫 Ticket #${pad(t.id)} • ${t.categoryName}`)
    .setDescription(`**Assunto:** ${cut(t.subject, 200)}\n\n${cut(t.description, 1500)}`)
    .addFields(
      { name: 'Aberto por', value: `<@${t.openerId}>`, inline: true },
      { name: 'Atendente', value: t.claimedBy ? `<@${t.claimedBy}>` : '⏳ Aguardando atendimento', inline: true },
      { name: 'Aberto', value: `<t:${Math.floor(t.createdAt / 1000)}:R>`, inline: true },
    )
    .setFooter({ text: 'Para fechar o ticket use o botão abaixo.' });
  return {
    embeds: [embed],
    components: [row(
      btn(`tk:claim:${t.id}`, t.claimedBy ? 'Assumido' : 'Assumir', Success, '🙋').setDisabled(Boolean(t.claimedBy)),
      btn(`tk:add:${t.id}`, 'Adicionar', Secondary, '➕'),
      btn(`tk:rm:${t.id}`, 'Remover', Secondary, '➖'),
      btn(`tk:close:${t.id}`, 'Fechar', Danger, '🔒'),
    )],
  };
}

async function slog(client, payload) {
  const id = sup().logChannelId || config.logChannelId;
  if (!id) return;
  try {
    const c = await client.channels.fetch(id);
    await c.send({ allowedMentions: { parse: [] }, ...payload });
  } catch (e) { console.error('[support:log]', e.message); }
}
const logEmbed = (title, t, color, extra = []) =>
  new EmbedBuilder().setTitle(`${title} • #${pad(t.id)}`).setColor(color).setTimestamp()
    .addFields({ name: 'Categoria', value: t.categoryName, inline: true }, { name: 'Aberto por', value: `<@${t.openerId}>`, inline: true }, ...extra);

/** Tickets abertos do usuário. Quem teve o canal apagado na mão é encerrado automaticamente. */
function openTicketsOf(guild, userId) {
  return tickets.all().filter((t) => {
    if (t.status !== 'open' || t.openerId !== userId || t.guildId !== guild.id) return false;
    if (!guild.channels.cache.has(t.channelId)) {
      t.status = 'closed'; t.closedAt = Date.now(); t.closeReason = 'Canal removido manualmente';
      tickets.save();
      return false;
    }
    return true;
  });
}

// ======================================================================
// Transcrição (HTML)
// ======================================================================
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtTime = (ts) => new Date(ts).toLocaleString('pt-BR', { timeZone: TZ });

async function fetchAll(channel) {
  const all = [];
  let before;
  for (let n = 0; n < 10; n++) {
    const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
    if (!batch || !batch.size) break;
    all.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  return all.reverse();
}

function transcriptHtml(t, msgs, guildName) {
  const intentOff = process.env.MESSAGE_CONTENT_INTENT !== 'true';
  const body = msgs.map((m) => {
    const content = m.cleanContent || '';
    const atts = [...m.attachments.values()].map((a) => `<div class="att">📎 <a href="${esc(a.url)}">${esc(a.name)}</a></div>`).join('');
    const embeds = m.embeds.map((e) => `<div class="emb"><b>${esc(e.title || '')}</b><div>${esc(cut(e.description || '', 600)).replace(/\n/g, '<br>')}</div></div>`).join('');
    return `<div class="msg"><img class="av" src="${esc(m.author.displayAvatarURL({ extension: 'png', size: 64 }))}" alt=""><div class="bd">` +
      `<span class="nm">${esc(m.author.tag)}${m.author.bot ? ' <i>BOT</i>' : ''}</span><span class="tm">${esc(fmtTime(m.createdTimestamp))}</span>` +
      `<div class="ct">${esc(content).replace(/\n/g, '<br>')}</div>${atts}${embeds}</div></div>`;
  }).join('\n');
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>Ticket #${pad(t.id)}</title><style>
body{background:#313338;color:#dbdee1;font-family:Segoe UI,Arial,sans-serif;margin:0;padding:24px}
.hd{background:#2b2d31;border-radius:8px;padding:16px;margin-bottom:20px}.hd h1{margin:0 0 8px;font-size:20px;color:#fff}.hd div{font-size:14px;color:#b5bac1;margin:2px 0}
.warn{background:#4a3b12;color:#fee75c;border-radius:6px;padding:10px;margin-bottom:16px;font-size:13px}
.msg{display:flex;gap:12px;padding:6px 0}.av{width:40px;height:40px;border-radius:50%}.bd{min-width:0}.nm{font-weight:600;color:#fff;margin-right:8px}.nm i{background:#5865f2;color:#fff;font-size:10px;padding:1px 4px;border-radius:3px;font-style:normal}
.tm{font-size:12px;color:#949ba4}.ct{white-space:normal;word-wrap:break-word;margin-top:2px}.att{margin-top:4px}.att a{color:#00a8fc}
.emb{border-left:4px solid #5865f2;background:#2b2d31;padding:8px 12px;margin-top:6px;border-radius:4px;font-size:14px}</style></head><body>
<div class="hd"><h1>🎫 Ticket #${pad(t.id)} — ${esc(t.categoryName)}</h1>
<div><b>Servidor:</b> ${esc(guildName)}</div><div><b>Aberto por:</b> ${esc(t.openerTag || t.openerId)} (${esc(t.openerId)})</div>
<div><b>Assunto:</b> ${esc(t.subject)}</div><div><b>Aberto em:</b> ${esc(fmtTime(t.createdAt))}</div><div><b>Mensagens:</b> ${msgs.length}</div></div>
${intentOff ? '<div class="warn">⚠️ O "Message Content Intent" do bot está desligado: o texto das mensagens dos membros não pode ser salvo (anexos, embeds e mensagens do bot aparecem normalmente).</div>' : ''}
${body}
</body></html>`;
}

// ======================================================================
// Abrir ticket
// ======================================================================
async function startOpen(i, key) {
  const cat = findCategory(key);
  if (!cat) return i.reply({ content: '❌ Essa categoria não existe mais. Peça para a staff atualizar o painel.', flags: EPH });
  if (openTicketsOf(i.guild, i.user.id).length >= sup().maxOpenPerUser) {
    const mine = openTicketsOf(i.guild, i.user.id)[0];
    return i.reply({ content: `❌ Você já tem ${sup().maxOpenPerUser > 1 ? 'o limite de tickets abertos' : 'um ticket aberto'}: <#${mine.channelId}>`, flags: EPH });
  }
  const input = (id, label, long, max, ph) => {
    const t = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(long ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(true).setMaxLength(max).setMinLength(long ? 10 : 3);
    if (ph) t.setPlaceholder(ph);
    return row(t);
  };
  return i.showModal(new ModalBuilder().setCustomId(`tk:modal:${key}`).setTitle(`Ticket • ${cat.name}`.slice(0, 45))
    .addComponents(
      input('subject', 'Assunto', false, 100, 'Resumo em poucas palavras'),
      input('desc', 'Descreva seu caso', true, 1000, 'Quanto mais detalhes, mais rápido conseguimos ajudar'),
    ));
}

async function submitOpen(i, key) {
  await i.deferReply({ flags: EPH });
  const fail = (m) => i.editReply({ content: `❌ ${m}` });
  const cat = findCategory(key);
  if (!cat) return fail('Essa categoria não existe mais.');
  const guild = i.guild;
  const mine = openTicketsOf(guild, i.user.id);
  if (mine.length >= sup().maxOpenPerUser) return fail(`Você já tem um ticket aberto: <#${mine[0].channelId}>`);

  const base = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks];
  const overwrites = [
    { id: guild.id, deny: [P.ViewChannel] },
    { id: i.user.id, allow: base },
    { id: i.client.user.id, allow: [...base, P.ManageChannels, P.ManageMessages] },
  ];
  if (staffRoleId()) overwrites.push({ id: staffRoleId(), allow: [...base, P.ManageMessages] });

  const t = tickets.create({
    guildId: guild.id, channelId: null, openerId: i.user.id, openerTag: i.user.tag,
    categoryKey: cat.key, categoryName: cat.name,
    subject: i.fields.getTextInputValue('subject').trim(),
    description: i.fields.getTextInputValue('desc').trim(),
    claimedBy: null, extraUsers: [],
  });

  let channel;
  try {
    channel = await guild.channels.create({
      name: `${cat.key}-${pad(t.id)}`.slice(0, 100),
      type: ChannelType.GuildText,
      parent: sup().categoryId || undefined,
      topic: `Ticket #${pad(t.id)} • ${cat.name} • aberto por ${i.user.tag} (${i.user.id})`,
      permissionOverwrites: overwrites,
    });
  } catch (e) {
    t.status = 'failed'; tickets.save();
    console.error('[ticket:create]', e);
    return fail('Não consegui criar o canal. Verifique se o bot tem **Gerenciar Canais** (e acesso à categoria configurada).');
  }
  t.channelId = channel.id;
  tickets.save();

  const welcome = sup().welcome.includes('{user}') ? sup().welcome.replaceAll('{user}', `<@${i.user.id}>`) : `<@${i.user.id}> ${sup().welcome}`;
  const msg = await channel.send({ content: `${welcome}\n${staffPing()}`.trim(), ...renderTicket(t) });
  await msg.pin().catch(() => {});
  t.mainMessageId = msg.id;
  tickets.save();

  await slog(i.client, { embeds: [logEmbed('🆕 Ticket aberto', t, 0x5865f2, [{ name: 'Canal', value: `${channel}`, inline: true }, { name: 'Assunto', value: cut(t.subject, 200) }])] });
  return i.editReply({ content: `✅ Ticket criado: ${channel}` });
}

// ======================================================================
// Atendimento: assumir, adicionar/remover, fechar
// ======================================================================
const ticketFromChannel = (i, id) => {
  const t = tickets.get(id);
  return t && t.status === 'open' && t.channelId === i.channelId ? t : null;
};

async function claim(i, id) {
  const t = ticketFromChannel(i, id);
  if (!t) return i.reply({ content: '❌ Ticket não encontrado ou já encerrado.', flags: EPH });
  if (!isSupportStaff(i)) return i.reply({ content: '⛔ Apenas a equipe de atendimento pode assumir tickets.', flags: EPH });
  if (t.claimedBy) return i.reply({ content: `ℹ️ Este ticket já foi assumido por <@${t.claimedBy}>.`, flags: EPH });
  t.claimedBy = i.user.id; t.claimedAt = Date.now();
  tickets.save();
  await i.update(renderTicket(t));
  await i.channel.send({ content: `🙋 <@${i.user.id}> assumiu este ticket e vai te atender, <@${t.openerId}>.` }).catch(() => {});
  await slog(i.client, { embeds: [logEmbed('🙋 Ticket assumido', t, 0x57f287, [{ name: 'Atendente', value: `<@${i.user.id}>`, inline: true }])] });
}

async function askUser(i, id, mode) {
  const t = ticketFromChannel(i, id);
  if (!t) return i.reply({ content: '❌ Ticket não encontrado ou já encerrado.', flags: EPH });
  if (!isSupportStaff(i)) return i.reply({ content: '⛔ Apenas a equipe de atendimento pode fazer isso.', flags: EPH });
  return i.reply({
    content: mode === 'add' ? '➕ Escolha quem deve ter acesso a este ticket:' : '➖ Escolha quem deve perder o acesso a este ticket:',
    components: [row(new UserSelectMenuBuilder().setCustomId(`tk:${mode === 'add' ? 'adduser' : 'rmuser'}:${id}`).setPlaceholder('Selecione um usuário'))],
    flags: EPH,
  });
}

async function applyUser(i, id, mode) {
  const t = ticketFromChannel(i, id);
  if (!t) return i.update({ content: '❌ Ticket não encontrado ou já encerrado.', components: [] });
  if (!isSupportStaff(i)) return i.update({ content: '⛔ Sem permissão.', components: [] });
  const userId = i.values[0];
  const user = i.users.get(userId);
  if (!user || user.bot) return i.update({ content: '❌ Escolha um usuário válido (não bots).', components: [] });
  try {
    if (mode === 'add') {
      const member = await i.guild.members.fetch(userId).catch(() => null);
      if (!member) return i.update({ content: '❌ Esse usuário não está no servidor.', components: [] });
      await i.channel.permissionOverwrites.edit(userId, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      if (!t.extraUsers.includes(userId)) t.extraUsers.push(userId);
      tickets.save();
      await i.channel.send({ content: `➕ <@${userId}> foi adicionado ao ticket por <@${i.user.id}>.` });
      await slog(i.client, { embeds: [logEmbed('➕ Usuário adicionado', t, 0x5865f2, [{ name: 'Usuário', value: `<@${userId}>`, inline: true }, { name: 'Por', value: `<@${i.user.id}>`, inline: true }])] });
    } else {
      if (userId === t.openerId) return i.update({ content: '❌ Não é possível remover quem abriu o ticket.', components: [] });
      if (!i.channel.permissionOverwrites.cache.has(userId)) return i.update({ content: 'ℹ️ Esse usuário não tem acesso individual a este ticket.', components: [] });
      await i.channel.permissionOverwrites.delete(userId);
      t.extraUsers = t.extraUsers.filter((u) => u !== userId);
      tickets.save();
      await i.channel.send({ content: `➖ <@${userId}> foi removido do ticket por <@${i.user.id}>.` });
      await slog(i.client, { embeds: [logEmbed('➖ Usuário removido', t, 0xfaa61a, [{ name: 'Usuário', value: `<@${userId}>`, inline: true }, { name: 'Por', value: `<@${i.user.id}>`, inline: true }])] });
    }
  } catch (e) {
    return i.update({ content: `❌ Não consegui alterar as permissões: ${e.message}`, components: [] });
  }
  return i.update({ content: `✅ Feito: <@${userId}> ${mode === 'add' ? 'adicionado' : 'removido'}.`, components: [] });
}

async function startClose(i, id) {
  const t = ticketFromChannel(i, id);
  if (!t) return i.reply({ content: '❌ Ticket não encontrado ou já encerrado.', flags: EPH });
  if (!isSupportStaff(i) && i.user.id !== t.openerId) return i.reply({ content: '⛔ Apenas quem abriu o ticket ou a equipe pode fechá-lo.', flags: EPH });
  const reason = new TextInputBuilder().setCustomId('reason').setLabel('Motivo do encerramento (opcional)').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(500);
  return i.showModal(new ModalBuilder().setCustomId(`tk:closem:${id}`).setTitle(`Fechar ticket #${pad(t.id)}`).addComponents(row(reason)));
}

async function closeTicket(i, id) {
  const t = ticketFromChannel(i, id);
  if (!t) return i.reply({ content: '❌ Ticket não encontrado ou já encerrado.', flags: EPH });
  if (!isSupportStaff(i) && i.user.id !== t.openerId) return i.reply({ content: '⛔ Sem permissão.', flags: EPH });
  await i.deferReply({ flags: EPH });
  const reason = (i.fields.getTextInputValue('reason') || '').trim() || 'Não informado';

  t.status = 'closing'; // evita fechar duas vezes
  tickets.save();
  const channel = i.channel;
  await channel.send({
    embeds: [new EmbedBuilder().setColor(0xed4245).setTitle('🔒 Ticket encerrado')
      .setDescription(`Fechado por <@${i.user.id}>.\n**Motivo:** ${cut(reason, 500)}\n\nEste canal será apagado em **5 segundos**.`).setTimestamp()],
  }).catch(() => {});

  const msgs = await fetchAll(channel);
  const file = () => new AttachmentBuilder(Buffer.from(transcriptHtml(t, msgs, i.guild.name), 'utf8'), { name: `ticket-${pad(t.id)}.html` });
  t.status = 'closed'; t.closedAt = Date.now(); t.closedBy = i.user.id; t.closeReason = reason; t.messageCount = msgs.length;
  tickets.save();

  const mins = Math.max(1, Math.round((t.closedAt - t.createdAt) / 60000));
  await slog(i.client, {
    embeds: [logEmbed('🔒 Ticket fechado', t, 0xed4245, [
      { name: 'Fechado por', value: `<@${i.user.id}>`, inline: true },
      { name: 'Atendente', value: t.claimedBy ? `<@${t.claimedBy}>` : '—', inline: true },
      { name: 'Duração', value: `${mins} min • ${msgs.length} msgs`, inline: true },
      { name: 'Assunto', value: cut(t.subject, 200) },
      { name: 'Motivo', value: cut(reason, 500) },
    ])],
    files: [file()],
  });

  // DM para quem abriu: transcrição + avaliação
  let dmOk = false;
  try {
    const opener = await i.client.users.fetch(t.openerId);
    const payload = {
      embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle(`🎫 Seu ticket #${pad(t.id)} foi encerrado`)
        .setDescription(`**Servidor:** ${i.guild.name}\n**Categoria:** ${t.categoryName}\n**Motivo:** ${cut(reason, 400)}${sup().ratingEnabled ? '\n\nComo foi o atendimento? Avalie abaixo:' : ''}`).setTimestamp()],
      files: [file()],
    };
    if (sup().ratingEnabled) {
      payload.components = [row(...[1, 2, 3, 4, 5].map((n) => btn(`tk:rate:${t.id}:${n}`, String(n), n >= 4 ? Success : n === 3 ? Secondary : Danger, '⭐')))];
    }
    await opener.send(payload);
    dmOk = true;
  } catch { /* DM fechada */ }

  setTimeout(() => channel.delete(`Ticket #${pad(t.id)} encerrado por ${i.user.tag}`).catch((e) => console.error('[ticket:delete]', e.message)), 5000);
  return i.editReply(`✅ Ticket encerrado. Transcrição salva${dmOk ? ' e enviada por DM ao usuário' : ' (não consegui enviar DM ao usuário)'}.`);
}

async function rate(i, id, stars) {
  const t = tickets.get(id);
  if (!t || t.openerId !== i.user.id) return i.reply({ content: '❌ Você não pode avaliar este ticket.', flags: EPH });
  if (t.rating) return i.update({ components: [] });
  t.rating = Number(stars);
  t.ratedAt = Date.now();
  tickets.save();
  await i.update({
    embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('✅ Obrigado pela avaliação!').setDescription(`Você avaliou o ticket #${pad(t.id)} com ${'⭐'.repeat(t.rating)}.`)],
    components: [],
  });
  await slog(i.client, {
    embeds: [logEmbed('⭐ Avaliação recebida', t, 0xfee75c, [
      { name: 'Nota', value: `${'⭐'.repeat(t.rating)} (${t.rating}/5)`, inline: true },
      { name: 'Atendente', value: t.claimedBy ? `<@${t.claimedBy}>` : '—', inline: true },
    ])],
  });
}

// ======================================================================
// Roteador dos botões/modais do ticket (customId "tk:...")
// ======================================================================
async function handle(i) {
  const [, action, a, b] = i.customId.split(':');
  if (i.isButton()) {
    if (action === 'rate') return rate(i, a, b);
    if (!i.guild) return undefined;
    if (action === 'open') return startOpen(i, a);
    if (action === 'claim') return claim(i, a);
    if (action === 'add') return askUser(i, a, 'add');
    if (action === 'rm') return askUser(i, a, 'rm');
    if (action === 'close') return startClose(i, a);
  } else if (i.isModalSubmit()) {
    if (action === 'modal') return submitOpen(i, a);
    if (action === 'closem') return closeTicket(i, a);
  } else if (i.isUserSelectMenu()) {
    if (action === 'adduser') return applyUser(i, a, 'add');
    if (action === 'rmuser') return applyUser(i, a, 'rm');
  }
  return undefined;
}

// ======================================================================
// /config → Moderação e suporte
// ======================================================================
function supView(notice) {
  const s = sup();
  const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('🛡️ Moderação e suporte')
    .setDescription('Tudo é salvo na hora. Para publicar o painel de tickets use **/painel-ticket** no canal desejado (se já foi enviado, mudanças de aparência e categorias atualizam a mensagem sozinhas).')
    .addFields(
      { name: 'Canal de auditoria', value: `${ch(config.auditChannelId)}\nRecebe o registro de /ban, /kick, /say, /embed, /time-out, /lock e /unlock.`, inline: false },
      { name: 'Categoria dos tickets', value: ch(s.categoryId), inline: true },
      { name: 'Logs e transcrições', value: s.logChannelId ? ch(s.logChannelId) : `${ch(config.logChannelId)}\n(usa o canal de logs do MID)`, inline: true },
      { name: 'Cargo atendente', value: staffRoleId() ? `<@&${staffRoleId()}>${s.staffRoleId ? '' : '\n(usa o cargo da staff do MID)'}` : '`não definido`', inline: true },
      { name: 'Painel', value: s.panelChannelId ? `Enviado em ${ch(s.panelChannelId)}` : '`ainda não enviado` — use /painel-ticket', inline: true },
      { name: 'Opções', value: `Máx. ${s.maxOpenPerUser} aberto(s) por usuário\nAvaliação: ${s.ratingEnabled ? 'ligada' : 'desligada'}`, inline: true },
      { name: 'Categorias', value: s.categories.map((c) => `${c.emoji} **${c.name}**${c.description ? ` — ${c.description}` : ''}`).join('\n') || '—', inline: false },
    );
  return {
    content: notice || '', embeds: [embed],
    components: [
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:sup:audit').setPlaceholder('Canal de auditoria (moderação)').setChannelTypes(ChannelType.GuildText)),
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:sup:cat').setPlaceholder('Categoria onde os tickets serão criados').setChannelTypes(ChannelType.GuildCategory)),
      row(new ChannelSelectMenuBuilder().setCustomId('cfg:sup:log').setPlaceholder('Canal de logs e transcrições dos tickets').setChannelTypes(ChannelType.GuildText)),
      row(new RoleSelectMenuBuilder().setCustomId('cfg:sup:staff').setPlaceholder('Cargo que atende os tickets')),
      row(
        btn('cfg:sup:m:panel', 'Aparência do painel', Primary, '🎨'),
        btn('cfg:sup:m:cats', 'Categorias', Primary, '🗂️'),
        btn('cfg:sup:m:opts', 'Opções', Secondary, '⚙️'),
        btn('cfg:view:main', 'Voltar', Secondary, '⬅️'),
      ),
    ],
  };
}

function cfgModal(id, title, fields) {
  const m = new ModalBuilder().setCustomId(id).setTitle(title);
  for (const f of fields) {
    const t = new TextInputBuilder().setCustomId(f.id).setLabel(f.label).setStyle(f.long ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(Boolean(f.required));
    if (f.max) t.setMaxLength(f.max);
    if (f.placeholder) t.setPlaceholder(f.placeholder);
    if (f.value) t.setValue(String(f.value).slice(0, f.max || 4000));
    m.addComponents(row(t));
  }
  return m;
}

function buildCfgModal(name) {
  const s = sup();
  switch (name) {
    case 'panel':
      return cfgModal('cfg:sup:ms:panel', 'Aparência do painel de tickets', [
        { id: 'title', label: 'Título', value: s.panel.title, required: true, max: 100 },
        { id: 'description', label: 'Descrição', value: s.panel.description, long: true, required: true, max: 1500 },
        { id: 'image', label: 'URL da imagem/banner (opcional)', value: s.panel.image, max: 500 },
        { id: 'color', label: 'Cor da barra lateral (hex)', value: s.panel.color, required: true, max: 7 },
      ]);
    case 'cats':
      return cfgModal('cfg:sup:ms:cats', 'Categorias de ticket (até 5)', [
        { id: 'cats', label: 'emoji | nome | descrição (1 por linha)', value: categoriesToText(s.categories), long: true, required: true, max: 1000, placeholder: '🚨 | Denúncia | Denuncie um membro' },
      ]);
    case 'opts':
      return cfgModal('cfg:sup:ms:opts', 'Opções do suporte', [
        { id: 'max', label: 'Máx. tickets abertos por usuário (1 a 5)', value: s.maxOpenPerUser, required: true, max: 1 },
        { id: 'rating', label: 'Pedir avaliação por DM ao fechar? sim/não', value: s.ratingEnabled ? 'sim' : 'não', required: true, max: 5 },
        { id: 'welcome', label: 'Mensagem de boas-vindas ({user} = menção)', value: s.welcome, long: true, required: true, max: 800 },
      ]);
    default:
      return null;
  }
}

function applyCfgModal(name, f) {
  const get = (id) => (f.getTextInputValue(id) || '').trim();
  const s = sup();
  switch (name) {
    case 'panel': {
      const color = get('color');
      if (!/^#?[0-9a-f]{6}$/i.test(color)) throw new Error('Cor inválida. Use hex, ex: #5865F2');
      const image = get('image');
      if (image && !/^https?:\/\/\S+$/i.test(image)) throw new Error('A imagem deve ser uma URL http(s).');
      s.panel = { title: get('title').slice(0, 100), description: get('description').slice(0, 1500), image, color: color.startsWith('#') ? color : `#${color}` };
      return 'Aparência do painel salva.';
    }
    case 'cats':
      s.categories = parseCategories(f.getTextInputValue('cats'));
      return 'Categorias salvas.';
    case 'opts': {
      const max = Number(get('max'));
      if (!(Number.isInteger(max) && max >= 1 && max <= 5)) throw new Error('Tickets por usuário: de 1 a 5.');
      s.maxOpenPerUser = max;
      s.ratingEnabled = /^(s|sim|true|1|yes|ligad)/i.test(get('rating'));
      s.welcome = get('welcome').slice(0, 800);
      return 'Opções salvas.';
    }
    default:
      throw new Error('Modal desconhecido.');
  }
}

/** Trata todos os customId "cfg:sup:*" (a checagem de administrador já foi feita pelo config.js). */
async function handleConfig(i) {
  const id = i.customId;
  const parts = id.split(':'); // cfg, sup, kind, name
  const kind = parts[2];

  if (i.isButton()) {
    if (kind === 'view') return i.update(supView());
    if (kind === 'm') return i.showModal(buildCfgModal(parts[3]));
  }

  if (i.isModalSubmit() && kind === 'ms') {
    const name = parts[3];
    let notice;
    try { notice = applyCfgModal(name, i.fields); } catch (e) { return i.reply({ content: `❌ ${e.message}`, flags: EPH }); }
    saveConfig();
    let extra = '';
    if (name === 'panel' || name === 'cats') {
      extra = await refreshPanel(i.client) ? ' Painel publicado atualizado.' : (sup().panelChannelId ? ' (Não consegui atualizar o painel publicado — reenvie com /painel-ticket.)' : '');
    }
    const view = supView(`✅ ${notice}${extra}`);
    return i.isFromMessage() ? i.update(view) : i.reply({ ...view, flags: EPH });
  }

  if (i.isChannelSelectMenu()) {
    const v = i.values[0];
    if (kind === 'audit') config.auditChannelId = v;
    else if (kind === 'cat') sup().categoryId = v;
    else if (kind === 'log') sup().logChannelId = v;
    else return undefined;
    saveConfig();
    return i.update(supView());
  }
  if (i.isRoleSelectMenu() && kind === 'staff') {
    sup().staffRoleId = i.values[0];
    saveConfig();
    return i.update(supView());
  }
  return undefined;
}

module.exports = { commands, sendPanelCommand, handle, handleConfig, supView, buildPanel, parseCategories, renderTicket, transcriptHtml, buildCfgModal };

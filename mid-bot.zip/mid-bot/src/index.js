'use strict';
require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, PermissionFlagsBits, MessageFlags, Events } = require('discord.js');
const cfg = require('./config');
const mid = require('./mid');
const { startWebhookServer } = require('./webhook');

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error('Defina DISCORD_TOKEN e CLIENT_ID no arquivo .env (veja .env.example).');
  process.exit(1);
}

const intents = [GatewayIntentBits.Guilds];
if (process.env.MESSAGE_CONTENT_INTENT === 'true') intents.push(GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent);
const client = new Client({ intents });

const commands = [
  new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configura o sistema de Middleman (somente administradores)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .toJSON(),
];

client.once(Events.ClientReady, async (c) => {
  console.log(`Logado como ${c.user.tag}`);
  mid.init(client);
  try {
    if (process.env.GUILD_ID) await c.application.commands.set(commands, process.env.GUILD_ID);
    else await c.application.commands.set(commands);
    console.log('Comandos registrados.');
  } catch (e) {
    console.error('Falha ao registrar comandos:', e.message);
  }
  mid.startPoller();
  const port = process.env.WEBHOOK_PORT || process.env.PORT;
  if (port) startWebhookServer(Number(port));
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'config') return await cfg.showPanel(interaction);
      return;
    }
    const id = interaction.customId || '';
    if (id.startsWith('cfg:')) return await cfg.handle(interaction);
    if (id.startsWith('mid:')) {
      if (interaction.isButton()) return await mid.handleButton(interaction);
      if (interaction.isModalSubmit()) return await mid.handleModal(interaction);
      if (interaction.isUserSelectMenu()) return await mid.handleUserSelect(interaction);
    }
  } catch (e) {
    console.error('[interaction]', e);
    const payload = { content: '❌ Ocorreu um erro inesperado. Tente novamente ou chame a staff.', flags: MessageFlags.Ephemeral };
    try {
      if (interaction.deferred || interaction.replied) await interaction.followUp(payload);
      else await interaction.reply(payload);
    } catch { /* interação expirada */ }
  }
});

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
client.login(process.env.DISCORD_TOKEN);

'use strict';
require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, PermissionFlagsBits, MessageFlags, Events } = require('discord.js');
const cfg = require('./config');
const mid = require('./mid');
const profile = require('./profile');
const moderation = require('./moderation');
const support = require('./support');
const { startWebhookServer } = require('./webhook');

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error('Defina DISCORD_TOKEN e CLIENT_ID no arquivo .env (veja .env.example).');
  process.exit(1);
}

const intents = [GatewayIntentBits.Guilds];
// Necessário para dar o cargo "Trader Iniciante" a quem entra (ative "Server Members Intent" no Developer Portal)
if (process.env.MEMBERS_INTENT !== 'false') intents.push(GatewayIntentBits.GuildMembers);
if (process.env.MESSAGE_CONTENT_INTENT === 'true') intents.push(GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent);
const client = new Client({ intents });

const commands = [
  new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configura o sistema de Middleman (somente administradores)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .toJSON(),
  ...moderation.commands,
  ...support.commands,
];

client.once(Events.ClientReady, async (c) => {
  console.log(`Logado como ${c.user.tag}`);
  mid.init(client);
  try {
    if (process.env.GUILD_ID) await c.application.commands.set(commands, process.env.GUILD_ID);
    else await c.application.commands.set(commands);
    console.log('Comandos registrados.');
  } catch (e) {
    console.error('Falha ao registrar comandos:', e.message);
  }
  mid.startPoller();
  const port = process.env.WEBHOOK_PORT || process.env.PORT;
  if (port) startWebhookServer(Number(port));
});

client.on(Events.GuildMemberAdd, (member) => profile.onMemberJoin(member));

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'config') return await cfg.showPanel(interaction);
      if (interaction.commandName === 'painel-ticket') return await support.sendPanelCommand(interaction);
      if (moderation.names.has(interaction.commandName)) return await moderation.handleCommand(interaction);
      return;
    }
    const id = interaction.customId || '';
    if (id.startsWith('cfg:')) return await cfg.handle(interaction);
    if (id.startsWith('prof:')) return await profile.handle(interaction);
    if (id.startsWith('tk:')) return await support.handle(interaction);
    if (id.startsWith('mod:') && interaction.isModalSubmit()) return await moderation.handleModal(interaction);
    if (id.startsWith('mid:')) {
      if (interaction.isButton()) return await mid.handleButton(interaction);
      if (interaction.isModalSubmit()) return await mid.handleModal(interaction);
      if (interaction.isUserSelectMenu()) return await mid.handleUserSelect(interaction);
      if (interaction.isStringSelectMenu()) return await mid.handleStringSelect(interaction);
    }
  } catch (e) {
    console.error('[interaction]', e);
    const payload = { content: '❌ Ocorreu um erro inesperado. Tente novamente ou chame a staff.', flags: MessageFlags.Ephemeral };
    try {
      if (interaction.deferred || interaction.replied) await interaction.followUp(payload);
      else await interaction.reply(payload);
    } catch { /* interação expirada */ }
  }
});

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
client.login(process.env.DISCORD_TOKEN);

'use strict';
const fs = require('fs');
const path = require('path');

const DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DIR, { recursive: true });

const DEFAULTS = {
  enabled: true,
  gateway: 'purincash', // 'eclipsepay' | 'purincash'
  eclipsepay: { apiKey: '', webhookSecret: '' },
  purincash: { apiKey: '', webhookSecret: '', turbo: false },
  publicUrl: '',
  // Taxa por faixa: vale a maior faixa em que o valor ficou "acima de". cents = fixo, percent = %.
  feeTiers: [
    { above: 250, cents: 120 },
    { above: 10000, cents: 250 },
    { above: 20000, cents: 500 },
    { above: 40000, cents: 800 },
    { above: 70000, percent: 1.2 },
  ],
  accountExtraPercent: 5, // % do valor somada à taxa em negociações com conta
  feePayer: 'buyer', // buyer | seller | split
  minCents: 250,
  maxCents: 100000,
  paymentExpiryMin: 30,
  maxOpenDeals: 3,
  idleCancelMin: 60,
  ticketCategoryId: '',
  logChannelId: '',
  vouchChannelId: '',
  staffRoleId: '',
  panelChannelId: '',
  panelMessageId: '',
  profilePanelChannelId: '',
  profilePanelMessageId: '',
  profilePanel: {
    image: '',
    text: 'Visualize seu perfil, veja seus benefícios e gerencie suas configurações em um só lugar.',
  },
  // Cargos automáticos: beginner = "Trader Iniciante" (todo membro); tiers[i] = cargo do nível i (mesma ordem dos níveis)
  roles: { beginner: '', tiers: ['', '', '', '', ''] },
  // Níveis por volume negociado (até 5, em ordem crescente). Cada um libera um emblema no perfil.
  tiers: [
    { name: 'Bronze', minCents: 10000, benefit: 'Emblema Bronze no perfil' },
    { name: 'Prata', minCents: 50000, benefit: 'Emblema Prata no perfil' },
    { name: 'Ouro', minCents: 200000, benefit: 'Emblema Ouro no perfil' },
    { name: 'Value', minCents: 500000, benefit: 'Emblema Value no perfil' },
    { name: 'Black', minCents: 1000000, benefit: 'Emblema Black no perfil' },
  ],
  panel: {
    title: '🤝 — Solicitar MM',
    color: '#8A2BE2',
    image: '',
    note: 'Não se aplica a alts de robux ( sem email )',
  },
  // Moderação: canal onde cada comando usado (/ban, /kick, /say...) é registrado
  auditChannelId: '',
  moderation: { locks: {} }, // estado anterior de cada canal trancado com /lock
  // Sistema de suporte (tickets). Painel enviado com /painel-ticket
  support: {
    categoryId: '', // categoria onde os tickets são criados
    logChannelId: '', // transcrições e logs (vazio = usa o canal de logs do MID)
    staffRoleId: '', // cargo que atende (vazio = usa o cargo da staff do MID)
    panelChannelId: '',
    panelMessageId: '',
    maxOpenPerUser: 1,
    ratingEnabled: true,
    welcome: 'Olá {user}! Nossa equipe já foi avisada e vai te atender em breve. Enquanto isso, descreva seu caso com o máximo de detalhes.',
    panel: {
      title: '🎫 — Central de Suporte',
      color: '#5865F2',
      image: '',
      description: 'Precisa de ajuda? Escolha uma categoria abaixo para abrir um ticket e nossa equipe vai te atender o mais rápido possível.',
    },
    categories: [
      { key: 'duvidas', emoji: '❓', name: 'Dúvidas', description: 'Tire dúvidas sobre o servidor ou o MID' },
      { key: 'denuncia', emoji: '🚨', name: 'Denúncia', description: 'Denuncie um membro ou situação' },
      { key: 'mid', emoji: '🤝', name: 'Problema com MID', description: 'Ajuda com uma negociação' },
      { key: 'outros', emoji: '📩', name: 'Outros', description: 'Qualquer outro assunto' },
    ],
  },
};

function readJson(file, def) {
  try {
    return JSON.parse(fs.readFileSync(path.join(DIR, file), 'utf8'));
  } catch {
    return def;
  }
}

function writeJson(file, obj) {
  const p = path.join(DIR, file);
  fs.writeFileSync(p + '.tmp', JSON.stringify(obj, null, 2));
  fs.renameSync(p + '.tmp', p);
}

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
function merge(base, extra) {
  const out = { ...base };
  for (const k of Object.keys(extra || {})) {
    out[k] = isObj(base[k]) && isObj(extra[k]) ? merge(base[k], extra[k]) : extra[k];
  }
  return out;
}

const saved = readJson('config.json', {});
// Migração: config antigo (taxa única %/mínimo) -> faixas novas + painel novo
if (!Array.isArray(saved.feeTiers)) {
  delete saved.feePercent;
  delete saved.feeMinCents;
  saved.minCents = DEFAULTS.minCents;
  if (saved.panel) saved.panel = { image: saved.panel.image || '' };
}
if (saved.panel) delete saved.panel.description;
const config = merge(DEFAULTS, saved);
const dealsFile = readJson('deals.json', { counter: 0, items: {} });
const usersFile = readJson('users.json', { items: {} });
const ticketsFile = readJson('tickets.json', { counter: 0, items: {} });

function saveConfig() {
  writeJson('config.json', config);
}

const deals = {
  create(data) {
    dealsFile.counter += 1;
    const id = String(dealsFile.counter);
    const deal = { id, createdAt: Date.now(), updatedAt: Date.now(), charges: [], ...data };
    dealsFile.items[id] = deal;
    this.save();
    return deal;
  },
  get: (id) => dealsFile.items[id] || null,
  all: () => Object.values(dealsFile.items),
  byChannel: (channelId) => Object.values(dealsFile.items).find((d) => d.channelId === channelId) || null,
  byCharge: (chargeId) =>
    Object.values(dealsFile.items).find((d) => (d.charges || []).some((c) => c.id === chargeId)) || null,
  byPayout: (payoutId) =>
    Object.values(dealsFile.items).find((d) => d.payout && d.payout.id === payoutId) || null,
  save() {
    writeJson('deals.json', dealsFile);
  },
};

// Preferências por usuário (ex.: esconder nome nos vouchs)
const users = {
  get: (id) => usersFile.items[id] || {},
  set(id, patch) {
    usersFile.items[id] = { ...(usersFile.items[id] || {}), ...patch };
    writeJson('users.json', usersFile);
  },
  isHidden: (id) => Boolean((usersFile.items[id] || {}).hideName),
};

// Tickets de suporte
const tickets = {
  create(data) {
    ticketsFile.counter += 1;
    const id = String(ticketsFile.counter);
    const ticket = { id, createdAt: Date.now(), status: 'open', ...data };
    ticketsFile.items[id] = ticket;
    this.save();
    return ticket;
  },
  get: (id) => ticketsFile.items[id] || null,
  all: () => Object.values(ticketsFile.items),
  byChannel: (channelId) => Object.values(ticketsFile.items).find((t) => t.channelId === channelId) || null,
  save() {
    writeJson('tickets.json', ticketsFile);
  },
};

saveConfig();
module.exports = { config, saveConfig, deals, users, tickets };

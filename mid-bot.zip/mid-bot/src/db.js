'use strict';
const fs = require('fs');
const path = require('path');

const DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DIR, { recursive: true });

const DEFAULTS = {
  enabled: true,
  gateway: 'purincash', // 'eclipsepay' | 'purincash'
  eclipsepay: { apiKey: '', webhookSecret: '' },
  purincash: { apiKey: '', webhookSecret: '', turbo: false },
  publicUrl: '',
  feePercent: 5,
  feeMinCents: 500,
  feePayer: 'buyer', // buyer | seller | split
  minCents: 500,
  maxCents: 100000,
  paymentExpiryMin: 30,
  maxOpenDeals: 3,
  idleCancelMin: 60,
  ticketCategoryId: '',
  logChannelId: '',
  staffRoleId: '',
  panelChannelId: '',
  panelMessageId: '',
  panel: {
    title: '🛡️ Middleman Automático',
    description:
      'Negocie com segurança! O pagamento do comprador fica **retido** pelo MID até a entrega ser confirmada.\n\n' +
      '**Como funciona**\n' +
      '1️⃣ Abra uma negociação e escolha se você é comprador ou vendedor\n' +
      '2️⃣ O vendedor aceita e informa a chave PIX para receber\n' +
      '3️⃣ O comprador paga o PIX gerado pelo bot\n' +
      '4️⃣ O vendedor entrega e o comprador libera o pagamento\n\n' +
      'Em caso de problema, abra uma disputa e a staff resolve.',
    color: '#5865F2',
    image: '',
  },
};

function readJson(file, def) {
  try {
    return JSON.parse(fs.readFileSync(path.join(DIR, file), 'utf8'));
  } catch {
    return def;
  }
}

function writeJson(file, obj) {
  const p = path.join(DIR, file);
  fs.writeFileSync(p + '.tmp', JSON.stringify(obj, null, 2));
  fs.renameSync(p + '.tmp', p);
}

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
function merge(base, extra) {
  const out = { ...base };
  for (const k of Object.keys(extra || {})) {
    out[k] = isObj(base[k]) && isObj(extra[k]) ? merge(base[k], extra[k]) : extra[k];
  }
  return out;
}

const config = merge(DEFAULTS, readJson('config.json', {}));
const dealsFile = readJson('deals.json', { counter: 0, items: {} });

function saveConfig() {
  writeJson('config.json', config);
}

const deals = {
  create(data) {
    dealsFile.counter += 1;
    const id = String(dealsFile.counter);
    const deal = { id, createdAt: Date.now(), updatedAt: Date.now(), charges: [], ...data };
    dealsFile.items[id] = deal;
    this.save();
    return deal;
  },
  get: (id) => dealsFile.items[id] || null,
  all: () => Object.values(dealsFile.items),
  byChannel: (channelId) => Object.values(dealsFile.items).find((d) => d.channelId === channelId) || null,
  byCharge: (chargeId) =>
    Object.values(dealsFile.items).find((d) => (d.charges || []).some((c) => c.id === chargeId)) || null,
  byPayout: (payoutId) =>
    Object.values(dealsFile.items).find((d) => d.payout && d.payout.id === payoutId) || null,
  save() {
    writeJson('deals.json', dealsFile);
  },
};

saveConfig();
module.exports = { config, saveConfig, deals };

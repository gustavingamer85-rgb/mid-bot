'use strict';
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, MessageFlags,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder,
} = require('discord.js');
const { config, deals, users } = require('./db');
const U = require('./utils');
const { renderProfileCard } = require('./profileCard');

const EPH = MessageFlags.Ephemeral;
const V2 = MessageFlags.IsComponentsV2;
const TZ = 'America/Sao_Paulo';
const TIER_COLORS = ['#cd7f32', '#c0c8d4', '#ffd24a', '#34d399', '#f3f4f6'];
const TOP_RANK = 10; // Top Trader: até o 10º do rank geral
const BIGGEST_CENTS = 50000; // Biggest Trader: alguma transação >= R$ 500
const OLD_DAYS = 90; // Old Bigger: 10+ trocas e primeira troca há 90+ dias
const OLD_MIN_TRADES = 10;

const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
const text = (c) => new TextDisplayBuilder().setContent(c);
const accent = () => parseInt(String(config.panel.color).replace('#', ''), 16) || 0x8a2be2;
const money = (c) => U.brl(c);

// ======================================================================
// Estatísticas (calculadas das negociações concluídas)
// ======================================================================
const monthKey = (ts) => new Date(ts).toLocaleDateString('en-CA', { timeZone: TZ }).slice(0, 7);

function allStats() {
  const nowKey = monthKey(Date.now());
  const map = new Map();
  for (const d of deals.all()) {
    if (d.status !== 'released') continue;
    const ts = d.completedAt || d.updatedAt || d.createdAt;
    for (const id of new Set([d.buyerId, d.sellerId])) {
      const s = map.get(id) || { total: 0, count: 0, max: 0, month: 0, first: ts };
      s.total += d.valueCents;
      s.count += 1;
      s.max = Math.max(s.max, d.valueCents);
      if (monthKey(ts) === nowKey) s.month += d.valueCents;
      s.first = Math.min(s.first, ts);
      map.set(id, s);
    }
  }
  return map;
}

function statsFor(userId) {
  const map = allStats();
  const s = map.get(userId) || { total: 0, count: 0, max: 0, month: 0, first: null };
  const entries = [...map.entries()];
  const rank = s.count ? entries.sort((a, b) => b[1].total - a[1].total).findIndex(([id]) => id === userId) + 1 : null;
  const mrank = s.month > 0
    ? entries.filter(([, v]) => v.month > 0).sort((a, b) => b[1].month - a[1].month).findIndex(([id]) => id === userId) + 1
    : null;
  return { ...s, rank, mrank };
}

const tiersList = () => [...config.tiers].sort((a, b) => a.minCents - b.minCents).slice(0, 5);

function currentTier(total) {
  let idx = -1;
  tiersList().forEach((t, i) => { if (total >= t.minCents) idx = i; });
  return idx;
}

function emblemsFor(s) {
  const list = tiersList().map((t, i) => ({ label: `Emblema ${t.name}`, color: TIER_COLORS[i] || '#a855f7', unlocked: s.total >= t.minCents }));
  list.push({ label: 'Top Trader', color: '#a855f7', unlocked: s.rank != null && s.rank <= TOP_RANK });
  list.push({ label: 'Biggest Trader', color: '#f97316', unlocked: s.max >= BIGGEST_CENTS });
  list.push({
    label: 'Old Bigger', color: '#38bdf8',
    unlocked: Boolean(s.first) && s.count >= OLD_MIN_TRADES && Date.now() - s.first >= OLD_DAYS * 86400000,
  });
  return list;
}

// ======================================================================
// Seu perfil (imagem)
// ======================================================================
async function fetchAvatar(url) {
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(6000) });
    if (!r.ok) return null;
    return Buffer.from(await r.arrayBuffer());
  } catch { return null; }
}

async function showProfile(interaction) {
  await interaction.deferReply({ flags: EPH });
  try {
    const s = statsFor(interaction.user.id);
    const ti = currentTier(s.total);
    const tiers = tiersList();
    const member = interaction.member && interaction.member.displayName ? interaction.member : null;
    const png = await renderProfileCard({
      name: member?.displayName || interaction.user.globalName || interaction.user.username,
      username: interaction.user.username,
      avatarBuffer: await fetchAvatar((member || interaction.user).displayAvatarURL({ extension: 'png', size: 256 })),
      tierName: ti >= 0 ? `Trader ${tiers[ti].name}` : 'Trader Iniciante',
      tierColor: ti >= 0 ? (TIER_COLORS[ti] || '#a855f7') : '#8b8a9b',
      stats: [
        { label: 'Total', value: money(s.total) },
        { label: 'Trocas', value: String(s.count) },
        { label: 'Maior Transação', value: money(s.max) },
        { label: 'Rank', value: s.rank ? `#${s.rank.toLocaleString('pt-BR')}` : '—', accent: true },
        { label: 'Rank Mensal', value: s.mrank ? `#${s.mrank.toLocaleString('pt-BR')}` : '—', accent: true },
        { label: 'Total Mensal', value: money(s.month), accent: true },
      ],
      emblems: emblemsFor(s),
    });
    return interaction.editReply({ files: [new AttachmentBuilder(png, { name: 'perfil.png' })] });
  } catch (e) {
    console.error('[perfil]', e);
    return interaction.editReply({ content: `❌ Não consegui gerar seu perfil: ${e.message}` });
  }
}

// ======================================================================
// Benefícios
// ======================================================================
function benefitsView(userId) {
  const s = statsFor(userId);
  const tiers = tiersList();
  const ti = currentTier(s.total);
  const lines = tiers.map((t, i) => `${i <= ti ? '✅' : '🔒'} **${t.name}** — a partir de ${money(t.minCents)} negociados\n-# ${t.benefit || 'Emblema no perfil'}`);
  let progress = ti >= 0 ? `Seu nível atual: **${tiers[ti].name}**.` : 'Você ainda não alcançou nenhum nível.';
  if (ti + 1 < tiers.length) progress += `\nFaltam **${money(tiers[ti + 1].minCents - s.total)}** para o nível **${tiers[ti + 1].name}**.`;
  else if (tiers.length) progress += '\nVocê está no nível máximo! 🎉';
  const special =
    `🔒 **Top Trader** — ficar entre os ${TOP_RANK} primeiros do rank\n` +
    `🔒 **Biggest Trader** — fechar uma transação de ${money(BIGGEST_CENTS)} ou mais\n` +
    `🔒 **Old Bigger** — ${OLD_MIN_TRADES}+ trocas e ${OLD_DAYS}+ dias desde a primeira`;
  const c = new ContainerBuilder().setAccentColor(accent())
    .addTextDisplayComponents(text('## 🎁 — Benefícios'))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(text(`${lines.join('\n')}\n\n${progress}`))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(text(`**Emblemas especiais**\n${special}`));
  return { components: [c], flags: V2 | EPH };
}

// ======================================================================
// Configurações
// ======================================================================
function settingsView(userId) {
  const hidden = users.isHidden(userId);
  const c = new ContainerBuilder().setAccentColor(accent())
    .addTextDisplayComponents(text('## ⚙️ — Configurações.'))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(text(`Esconder nome em vouchs: **${hidden ? 'ativado ✅' : 'desativado ❌'}**\n-# Quando ativado, seu nome aparece como \`Usuário oculto\` nos vouchs públicos.`))
    .addSeparatorComponents(sep())
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('prof:hide').setStyle(ButtonStyle.Secondary).setEmoji(hidden ? '✖️' : '✔️')
        .setLabel(hidden ? 'Desativar esconder nome' : 'Ativar esconder nome'),
    ));
  return { components: [c], flags: V2 | EPH };
}

// ======================================================================
// Painel fixo
// ======================================================================
function buildProfilePanel() {
  const c = new ContainerBuilder().setAccentColor(accent());
  if (config.profilePanel.image) {
    c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(config.profilePanel.image)));
    c.addSeparatorComponents(sep());
  }
  c.addTextDisplayComponents(text(`> ${String(config.profilePanel.text || '').replace(/\n/g, '\n> ')}`))
    .addSeparatorComponents(sep())
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('prof:me').setStyle(ButtonStyle.Secondary).setEmoji('👤').setLabel('Seu perfil'),
      new ButtonBuilder().setCustomId('prof:ben').setStyle(ButtonStyle.Secondary).setEmoji('🎁').setLabel('Benefícios'),
      new ButtonBuilder().setCustomId('prof:cfg').setStyle(ButtonStyle.Secondary).setEmoji('⚙️').setLabel('Configurações'),
    ));
  return { components: [c], flags: V2 };
}

// ======================================================================
// Cargos automáticos (Trader Iniciante + um por nível)
// ======================================================================
const roleSlots = () => (config.roles.tiers || []).slice(0, tiersList().length);

/** Deixa o membro com UM cargo de rank: o do maior nível atingido (ou Trader Iniciante). Retorna true se mudou algo. */
async function applyRoles(member, total) {
  const slots = roleSlots();
  const ti = currentTier(total);
  const want = (ti >= 0 && slots[ti]) || config.roles.beginner || '';
  const managed = [config.roles.beginner, ...(config.roles.tiers || [])].filter(Boolean);
  const remove = [...new Set(managed)].filter((id) => id !== want && member.roles.cache.has(id));
  let changed = false;
  if (remove.length) { await member.roles.remove(remove, 'MID: atualização de nível'); changed = true; }
  if (want && !member.roles.cache.has(want)) { await member.roles.add(want, 'MID: atualização de nível'); changed = true; }
  return changed;
}

async function syncUserRoles(client, guildId, userId) {
  try {
    const guild = await client.guilds.fetch(guildId);
    const member = await guild.members.fetch(userId);
    await applyRoles(member, statsFor(userId).total);
  } catch (e) { console.error('[cargos]', e.message); }
}

async function onMemberJoin(member) {
  if (member.user.bot) return;
  try { await applyRoles(member, statsFor(member.id).total); } catch (e) { console.error('[cargos/entrada]', e.message); }
}

async function syncAllRoles(guild) {
  const map = allStats();
  const members = await guild.members.fetch();
  const r = { total: 0, changed: 0, failed: 0, firstError: '' };
  for (const m of members.values()) {
    if (m.user.bot) continue;
    r.total += 1;
    try { if (await applyRoles(m, (map.get(m.id) || {}).total || 0)) r.changed += 1; } catch (e) { r.failed += 1; r.firstError ||= e.message; }
  }
  return r;
}

async function handle(interaction) {
  const id = interaction.customId;
  if (id === 'prof:me') return showProfile(interaction);
  if (id === 'prof:ben') return interaction.reply(benefitsView(interaction.user.id));
  if (id === 'prof:cfg') return interaction.reply(settingsView(interaction.user.id));
  if (id === 'prof:hide') {
    users.set(interaction.user.id, { hideName: !users.isHidden(interaction.user.id) });
    const v = settingsView(interaction.user.id);
    return interaction.update({ components: v.components, flags: V2 });
  }
}

module.exports = { handle, buildProfilePanel, statsFor, emblemsFor, tiersList, syncUserRoles, onMemberJoin, syncAllRoles };

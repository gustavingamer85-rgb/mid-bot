'use strict';
const store = require('../db');

function getGateway(name = store.config.gateway) {
  if (name === 'eclipsepay') return require('./eclipsepay')(store.config);
  if (name === 'purincash') return require('./purincash')(store.config);
  throw new Error(`Gateway desconhecido: ${name}`);
}

function gatewayReady(name = store.config.gateway) {
  return Boolean(store.config[name]?.apiKey);
}

module.exports = { getGateway, gatewayReady };

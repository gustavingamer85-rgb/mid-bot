'use strict';
const { randomUUID } = require('crypto');
const { request, sleep } = require('./http');

const BASE = () => process.env.ECLIPSEPAY_BASE_URL || 'https://eclipsepaybr.com/v1';

module.exports = (config) => {
  const apiKey = config.eclipsepay.apiKey;
  if (!apiKey) throw new Error('A chave de API da EclipsePay não foi configurada (/config).');
  const auth = { Authorization: `Bearer ${apiKey}` };
  const call = (method, path, opts = {}) =>
    request(method, BASE() + path, { ...opts, headers: { ...auth, ...(opts.headers || {}) } });

  const chargeStatus = (op) => {
    switch (op.status) {
      case 'completed': return 'paid';
      case 'failed':
      case 'refunded': return 'failed';
      default:
        return op.expiresAt && Date.parse(op.expiresAt) < Date.now() ? 'expired' : 'pending';
    }
  };

  const payoutStatus = (op) => {
    switch (op.status) {
      case 'completed': return 'completed';
      case 'failed':
      case 'refunded': return 'failed';
      default: return 'pending';
    }
  };

  return {
    name: 'EclipsePay',
    limits: { maxChargeCents: 100000 },

    async createCharge({ amountCents, description }) {
      const { data } = await call('POST', '/charges', {
        headers: { 'Idempotency-Key': randomUUID() },
        body: { amountCents, description: String(description).slice(0, 200) },
      });
      let op = data;
      // 202 = pendente: o brCode pode demorar alguns instantes
      for (let i = 0; i < 4 && !op.brCode && op.id && op.status === 'pending'; i++) {
        await sleep(1500);
        op = (await call('GET', `/charges/${op.id}`)).data;
      }
      if (!op.id || !op.brCode) {
        throw new Error(`A EclipsePay não devolveu o código PIX (status: ${op.status || 'desconhecido'}).`);
      }
      return { id: op.id, brCode: op.brCode, expiresAt: op.expiresAt || null };
    },

    async getCharge(id) {
      const { data } = await call('GET', `/charges/${encodeURIComponent(id)}`);
      return { status: chargeStatus(data), raw: data };
    },

    async createPayout({ amountCents, pixKey, pixKeyType, description, idempotencyKey }) {
      const { data } = await call('POST', '/payouts', {
        headers: { 'Idempotency-Key': idempotencyKey || randomUUID() },
        body: {
          amountCents,
          pixKey,
          ...(pixKeyType ? { pixKeyType } : {}),
          description: String(description || '').slice(0, 200),
        },
      });
      return { id: data.id, status: payoutStatus(data), raw: data };
    },

    async getPayout(id) {
      const { data } = await call('GET', `/payouts/${encodeURIComponent(id)}`);
      return { status: payoutStatus(data), raw: data };
    },

    async getBalance() {
      const { data } = await call('GET', '/balance');
      return { balanceCents: data.balanceCents, availableCents: data.availableCents, blockedCents: data.blockedCents };
    },
  };
};

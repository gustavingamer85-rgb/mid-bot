'use strict';

function extractMessage(data) {
  if (!data) return '';
  if (typeof data === 'string') return data;
  const m = data.message || data.error?.message || data.error || data.detail || data.raw;
  return typeof m === 'string' ? m : JSON.stringify(data).slice(0, 300);
}

/**
 * Faz a requisição. Em erro lança Error com:
 *  - err.status  (HTTP, se houve resposta)
 *  - err.ambiguous = true quando não dá pra saber se a operação foi executada
 *    (falha de rede/timeout/5xx) — importante para saques.
 */
async function request(method, url, { headers = {}, body, timeout = 20000 } = {}) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(timeout),
    });
  } catch (e) {
    const err = new Error(`Falha de rede ao falar com o gateway (${e.message})`);
    err.ambiguous = true;
    throw err;
  }
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text.slice(0, 300) };
  }
  if (!res.ok) {
    const err = new Error(`Gateway respondeu HTTP ${res.status}: ${extractMessage(data)}`);
    err.status = res.status;
    err.data = data;
    err.ambiguous = res.status >= 500;
    throw err;
  }
  return { status: res.status, data };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = { request, sleep };

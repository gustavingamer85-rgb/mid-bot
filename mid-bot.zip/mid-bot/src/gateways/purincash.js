'use strict';
const { request } = require('./http');

const BASE = () => process.env.PURINCASH_BASE_URL || 'https://api.purincash.com/v1';

const list = (d) => (Array.isArray(d) ? d : d?.data || d?.payouts || d?.items || d?.results || []);

module.exports = (config) => {
  const { apiKey, turbo } = config.purincash;
  if (!apiKey) throw new Error('A chave de API da PurinCash não foi configurada (/config).');
  const auth = { Authorization: `Bearer ${apiKey}` };
  const call = (method, path, opts = {}) =>
    request(method, BASE() + path, { ...opts, headers: { ...auth, ...(opts.headers || {}) } });

  const chargeStatus = (d) => {
    const s = String(d.status || d.charge?.status || '').toLowerCase();
    if (s === 'paid') return 'paid';
    if (s === 'expired') return 'expired';
    if (['refunded', 'cancelled', 'canceled', 'failed'].includes(s)) return 'failed';
    return 'pending';
  };

  const payoutStatus = (s) => {
    switch (String(s || '').toLowerCase()) {
      case 'completed':
      case 'concluido':
      case 'concluído': return 'completed';
      case 'denied':
      case 'negado':
      case 'falhou':
      case 'failed': return 'failed';
      default: return 'pending';
    }
  };

  return {
    name: 'PurinCash',
    limits: { maxChargeCents: Infinity },

    async createCharge({ amountCents, description, expiresInSec, metadata }) {
      const body = {
        valueCents: amountCents,
        description: String(description).slice(0, 200),
        expiresIn: Math.min(Math.max(expiresInSec || 1800, 60), 604800),
        metadata: JSON.stringify(metadata || {}),
      };
      if (config.publicUrl) body.callbackUrl = `${config.publicUrl.replace(/\/$/, '')}/webhook/purincash`;
      const { data } = await call('POST', '/charges', { body });
      const brCode = data.pix?.brCode;
      if (!data.paymentId || !brCode) throw new Error('A PurinCash não devolveu o código PIX.');
      return { id: data.paymentId, brCode, expiresAt: data.expiresAt || null };
    },

    async getCharge(id) {
      const { data } = await call('GET', `/charges/${encodeURIComponent(id)}`);
      return { status: chargeStatus(data), raw: data };
    },

    async createPayout({ amountCents, pixKey }) {
      // A PurinCash não tem Idempotency-Key: o bot evita reenvio duplicado por conta própria.
      const { data } = await call('POST', '/payouts', {
        body: { method: 'pix', amount: Number((amountCents / 100).toFixed(2)), walletAddress: pixKey, ...(turbo ? { turbo: true } : {}) },
      });
      const id = data.id || data.code || data.payout?.id;
      if (!id) throw new Error('A PurinCash aceitou o saque mas não devolveu o identificador.');
      return { id, status: payoutStatus(data.status), raw: data };
    },

    async getPayout(id) {
      const { data } = await call('GET', '/payouts?limit=100');
      const found = list(data).find((p) => p.id === id || p.code === id);
      if (!found) return { status: 'pending', raw: null };
      return { status: payoutStatus(found.status), raw: found };
    },

    async getBalance() {
      const { data } = await call('GET', '/wallet');
      return {
        balanceCents: data.balanceCents,
        availableCents: data.withdrawableCents,
        blockedCents: Math.round((data.disputeBlocked || 0) * 100),
      };
    },
  };
};

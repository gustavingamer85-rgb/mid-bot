'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType, MessageFlags,
  ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
} = require('discord.js');
const { config, saveConfig } = require('./db');
const U = require('./utils');

const EPH = MessageFlags.Ephemeral;
const P = PermissionFlagsBits;
const TEXT_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000;

// ======================================================================
// Definição dos comandos
// ======================================================================
const reasonOpt = (o, desc = 'Motivo') => o.setName('motivo').setDescription(desc).setMaxLength(400);

const commands = [
  new SlashCommandBuilder()
    .setName('ban').setDescription('Bane um membro do servidor')
    .setDefaultMemberPermissions(P.BanMembers).setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('Quem será banido').setRequired(true))
    .addStringOption((o) => reasonOpt(o, 'Motivo do banimento'))
    .addIntegerOption((o) => o.setName('apagar_mensagens').setDescription('Apagar mensagens dos últimos X dias (0 a 7)').setMinValue(0).setMaxValue(7))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('kick').setDescription('Expulsa um membro do servidor')
    .setDefaultMemberPermissions(P.KickMembers).setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('Quem será expulso').setRequired(true))
    .addStringOption((o) => reasonOpt(o, 'Motivo da expulsão'))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('say').setDescription('Envia uma mensagem como o bot')
    .setDefaultMemberPermissions(P.ManageMessages).setDMPermission(false)
    .addChannelOption((o) => o.setName('canal').setDescription('Canal de destino (padrão: o atual)').addChannelTypes(...TEXT_TYPES))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('embed').setDescription('Envia um embed personalizado como o bot')
    .setDefaultMemberPermissions(P.ManageMessages).setDMPermission(false)
    .addChannelOption((o) => o.setName('canal').setDescription('Canal de destino (padrão: o atual)').addChannelTypes(...TEXT_TYPES))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('time-out').setDescription('Aplica (ou remove) um castigo de tempo em um membro')
    .setDefaultMemberPermissions(P.ModerateMembers).setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('Quem receberá o castigo').setRequired(true))
    .addStringOption((o) => o.setName('duracao').setDescription('Ex: 10m, 2h, 1d, 1h30m (máx. 28d) ou "remover"').setRequired(true).setMaxLength(20))
    .addStringOption((o) => reasonOpt(o, 'Motivo do castigo'))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('lock').setDescription('Tranca um canal: membros não poderão enviar mensagens')
    .setDefaultMemberPermissions(P.ManageChannels).setDMPermission(false)
    .addChannelOption((o) => o.setName('canal').setDescription('Canal a trancar (padrão: o atual)').addChannelTypes(...TEXT_TYPES))
    .addStringOption((o) => reasonOpt(o, 'Motivo'))
    .toJSON(),
  new SlashCommandBuilder()
    .setName('unlock').setDescription('Destranca um canal trancado com /lock')
    .setDefaultMemberPermissions(P.ManageChannels).setDMPermission(false)
    .addChannelOption((o) => o.setName('canal').setDescription('Canal a destrancar (padrão: o atual)').addChannelTypes(...TEXT_TYPES))
    .addStringOption((o) => reasonOpt(o, 'Motivo'))
    .toJSON(),
];
const names = new Set(commands.map((c) => c.name));

// ======================================================================
// Auditoria
// ======================================================================
/** Registra o uso de um comando no canal de auditoria. Retorna true se enviou. */
async function audit(interaction, { title, color = 0x5865f2, fields = [], description }) {
  if (!config.auditChannelId) return false;
  try {
    const ch = await interaction.client.channels.fetch(config.auditChannelId);
    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(title)
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .addFields(
        { name: 'Executor', value: `<@${interaction.user.id}>\n\`${interaction.user.id}\``, inline: true },
        { name: 'Onde', value: interaction.channelId ? `<#${interaction.channelId}>` : '—', inline: true },
        ...fields,
      )
      .setFooter({ text: `Comando: /${interaction.commandName || 'modal'}` })
      .setTimestamp();
    if (description) embed.setDescription(description.slice(0, 4000));
    await ch.send({ embeds: [embed], allowedMentions: { parse: [] } });
    return true;
  } catch (e) {
    console.error('[audit]', e.message);
    return false;
  }
}

const NO_AUDIT = '\n⚠️ Canal de auditoria não configurado (use **/config → Moderação e suporte**).';
const reasonText = (r) => (r && r.trim() ? r.trim() : 'Não informado');
const cut = (s, n = 1000) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));

// ======================================================================
// Helpers
// ======================================================================
const hasPerm = (i, flag) => U.isAdmin(i) || Boolean(i.memberPermissions?.has(flag));
const deny = (i, perm) => i.reply({ content: `⛔ Você precisa da permissão **${perm}** para usar este comando.`, flags: EPH });

/** Retorna mensagem de erro se o executor/bot não puder agir sobre o alvo; null se estiver tudo certo. */
function hierarchyError(i, target, verb) {
  const guild = i.guild;
  if (target.id === i.user.id) return `Você não pode ${verb} a si mesmo.`;
  if (target.id === i.client.user.id) return `Eu não posso ${verb} a mim mesmo.`;
  if (target.id === guild.ownerId) return `Não é possível ${verb} o dono do servidor.`;
  const mod = i.member;
  if (guild.ownerId !== mod.id && target.roles.highest.comparePositionTo(mod.roles.highest) >= 0) {
    return 'Esse membro tem um cargo igual ou acima do seu.';
  }
  const me = guild.members.me;
  if (me && target.roles.highest.comparePositionTo(me.roles.highest) >= 0) {
    return 'Esse membro tem um cargo igual ou acima do meu. Suba o cargo do bot na lista de cargos.';
  }
  return null;
}

async function tryDm(user, embed) {
  try { await user.send({ embeds: [embed] }); return true; } catch { return false; }
}

function dmEmbed(i, title, reason, color, extra) {
  const e = new EmbedBuilder().setColor(color).setTitle(title)
    .setDescription(`**Servidor:** ${i.guild.name}\n**Motivo:** ${cut(reason, 500)}${extra ? `\n${extra}` : ''}`)
    .setTimestamp();
  return e;
}

function parseDuration(input) {
  const s = String(input || '').toLowerCase().replace(/\s+/g, '');
  if (!s) return NaN;
  const units = { s: 1e3, seg: 1e3, m: 6e4, min: 6e4, h: 36e5, d: 864e5, w: 6048e5, sem: 6048e5 };
  const re = /(\d+)(seg|min|sem|s|m|h|d|w)/g;
  let total = 0;
  let used = 0;
  let m;
  while ((m = re.exec(s))) { total += Number(m[1]) * units[m[2]]; used += m[0].length; }
  return used === s.length && total > 0 ? total : NaN;
}

function fmtDuration(ms) {
  const parts = [];
  let r = Math.round(ms / 1000);
  for (const [label, sec] of [['d', 86400], ['h', 3600], ['min', 60], ['s', 1]]) {
    const n = Math.floor(r / sec);
    if (n) { parts.push(`${n}${label}`); r -= n * sec; }
  }
  return parts.join(' ') || '0s';
}

// ======================================================================
// Handlers
// ======================================================================
async function ban(i) {
  if (!hasPerm(i, P.BanMembers)) return deny(i, 'Banir Membros');
  const user = i.options.getUser('usuario', true);
  const reason = reasonText(i.options.getString('motivo'));
  const days = i.options.getInteger('apagar_mensagens') ?? 0;
  await i.deferReply({ flags: EPH });

  const member = await i.guild.members.fetch(user.id).catch(() => null);
  if (member) {
    const err = hierarchyError(i, member, 'banir');
    if (err) return i.editReply(`❌ ${err}`);
  } else if (user.id === i.user.id || user.id === i.client.user.id) {
    return i.editReply('❌ Alvo inválido.');
  }
  if (!member) {
    const already = await i.guild.bans.fetch(user.id).catch(() => null);
    if (already) return i.editReply('❌ Esse usuário já está banido.');
  }

  const dmOk = member ? await tryDm(user, dmEmbed(i, '🔨 Você foi banido', reason, 0xed4245)) : false;
  try {
    await i.guild.members.ban(user.id, { reason: `${reason} | por ${i.user.tag}`, deleteMessageSeconds: days * 86400 });
  } catch (e) {
    return i.editReply(`❌ Não consegui banir: ${e.message}`);
  }
  const logged = await audit(i, {
    title: '🔨 Banimento', color: 0xed4245,
    fields: [
      { name: 'Alvo', value: `<@${user.id}>\n\`${user.id}\``, inline: true },
      { name: 'Mensagens apagadas', value: days ? `Últimos ${days} dia(s)` : 'Nenhuma', inline: true },
      { name: 'Motivo', value: cut(reason) },
    ],
  });
  return i.editReply(`✅ **${user.tag}** foi banido.${member ? (dmOk ? '' : '\nℹ️ Não consegui avisar o usuário por DM.') : ''}${logged ? '' : NO_AUDIT}`);
}

async function kick(i) {
  if (!hasPerm(i, P.KickMembers)) return deny(i, 'Expulsar Membros');
  const user = i.options.getUser('usuario', true);
  const reason = reasonText(i.options.getString('motivo'));
  await i.deferReply({ flags: EPH });

  const member = await i.guild.members.fetch(user.id).catch(() => null);
  if (!member) return i.editReply('❌ Esse usuário não está no servidor.');
  const err = hierarchyError(i, member, 'expulsar');
  if (err) return i.editReply(`❌ ${err}`);

  const dmOk = await tryDm(user, dmEmbed(i, '👢 Você foi expulso', reason, 0xfaa61a));
  try {
    await member.kick(`${reason} | por ${i.user.tag}`);
  } catch (e) {
    return i.editReply(`❌ Não consegui expulsar: ${e.message}`);
  }
  const logged = await audit(i, {
    title: '👢 Expulsão', color: 0xfaa61a,
    fields: [{ name: 'Alvo', value: `<@${user.id}>\n\`${user.id}\``, inline: true }, { name: 'Motivo', value: cut(reason) }],
  });
  return i.editReply(`✅ **${user.tag}** foi expulso.${dmOk ? '' : '\nℹ️ Não consegui avisar o usuário por DM.'}${logged ? '' : NO_AUDIT}`);
}

async function timeout(i) {
  if (!hasPerm(i, P.ModerateMembers)) return deny(i, 'Castigar Membros');
  const user = i.options.getUser('usuario', true);
  const raw = i.options.getString('duracao', true).trim();
  const reason = reasonText(i.options.getString('motivo'));
  const removing = /^(remover|remove|0|off|tirar)$/i.test(raw);
  const ms = removing ? 0 : parseDuration(raw);
  if (!removing && !Number.isFinite(ms)) return i.reply({ content: '❌ Duração inválida. Use por exemplo `10m`, `2h`, `1d` ou `1h30m`.', flags: EPH });
  if (!removing && ms > MAX_TIMEOUT_MS) return i.reply({ content: '❌ O máximo permitido pelo Discord é **28 dias**.', flags: EPH });
  await i.deferReply({ flags: EPH });

  const member = await i.guild.members.fetch(user.id).catch(() => null);
  if (!member) return i.editReply('❌ Esse usuário não está no servidor.');
  const err = hierarchyError(i, member, 'castigar');
  if (err) return i.editReply(`❌ ${err}`);
  if (member.permissions.has(P.Administrator)) return i.editReply('❌ Não é possível aplicar castigo em administradores.');
  if (removing && !member.isCommunicationDisabled()) return i.editReply('❌ Esse membro não está de castigo.');

  try {
    await member.timeout(removing ? null : ms, `${reason} | por ${i.user.tag}`);
  } catch (e) {
    return i.editReply(`❌ Não consegui aplicar o castigo: ${e.message}`);
  }
  if (!removing) await tryDm(user, dmEmbed(i, '🔇 Você recebeu um castigo', reason, 0xfee75c, `**Duração:** ${fmtDuration(ms)}`));
  const until = removing ? null : Math.floor((Date.now() + ms) / 1000);
  const logged = await audit(i, {
    title: removing ? '🔊 Castigo removido' : '🔇 Time-out', color: removing ? 0x57f287 : 0xfee75c,
    fields: [
      { name: 'Alvo', value: `<@${user.id}>\n\`${user.id}\``, inline: true },
      ...(removing ? [] : [{ name: 'Duração', value: `${fmtDuration(ms)}\nTermina <t:${until}:R>`, inline: true }]),
      { name: 'Motivo', value: cut(reason) },
    ],
  });
  return i.editReply(`${removing ? `✅ Castigo de **${user.tag}** removido.` : `✅ **${user.tag}** ficará de castigo por **${fmtDuration(ms)}**.`}${logged ? '' : NO_AUDIT}`);
}

// ---- /say e /embed (via modal) ----
function textInput(id, label, { long = false, required = false, max, placeholder } = {}) {
  const t = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(long ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(required);
  if (max) t.setMaxLength(max);
  if (placeholder) t.setPlaceholder(placeholder);
  return new ActionRowBuilder().addComponents(t);
}

async function say(i) {
  if (!hasPerm(i, P.ManageMessages)) return deny(i, 'Gerenciar Mensagens');
  const target = i.options.getChannel('canal') || i.channel;
  const modal = new ModalBuilder().setCustomId(`mod:say:${target.id}`).setTitle('Enviar mensagem como o bot')
    .addComponents(textInput('text', 'Mensagem', { long: true, required: true, max: 2000, placeholder: 'Aceita quebras de linha e formatação do Discord' }));
  return i.showModal(modal);
}

async function embedCmd(i) {
  if (!hasPerm(i, P.ManageMessages)) return deny(i, 'Gerenciar Mensagens');
  const target = i.options.getChannel('canal') || i.channel;
  const modal = new ModalBuilder().setCustomId(`mod:embed:${target.id}`).setTitle('Criar embed')
    .addComponents(
      textInput('title', 'Título', { max: 256 }),
      textInput('desc', 'Descrição', { long: true, max: 4000 }),
      textInput('color', 'Cor (hex)', { max: 7, placeholder: '#5865F2' }),
      textInput('image', 'URL da imagem (opcional)', { max: 500 }),
      textInput('footer', 'Rodapé (opcional)', { max: 200 }),
    );
  return i.showModal(modal);
}

/** Valida se executor e bot podem postar no canal escolhido. Retorna o canal ou lança Error. */
async function resolveTarget(i, channelId) {
  const ch = await i.guild.channels.fetch(channelId).catch(() => null);
  if (!ch || !ch.isTextBased()) throw new Error('Canal não encontrado.');
  if (!ch.permissionsFor(i.member)?.has(P.ViewChannel)) throw new Error('Você não tem acesso a esse canal.');
  const me = ch.permissionsFor(i.guild.members.me);
  if (!me?.has([P.ViewChannel, P.SendMessages])) throw new Error(`Não tenho permissão para enviar mensagens em ${ch}.`);
  return ch;
}

async function handleModal(i) {
  const [, kind, channelId] = i.customId.split(':');
  if (!hasPerm(i, P.ManageMessages)) return i.reply({ content: '⛔ Sem permissão.', flags: EPH });
  await i.deferReply({ flags: EPH });
  let ch;
  try { ch = await resolveTarget(i, channelId); } catch (e) { return i.editReply(`❌ ${e.message}`); }

  if (kind === 'say') {
    const text = i.fields.getTextInputValue('text');
    if (!text.trim()) return i.editReply('❌ Mensagem vazia.');
    // Só quem pode mencionar @everyone/cargos consegue usar essas menções via bot
    const allowedMentions = hasPerm(i, P.MentionEveryone) ? undefined : { parse: ['users'] };
    let msg;
    try { msg = await ch.send({ content: text, allowedMentions }); } catch (e) { return i.editReply(`❌ Não consegui enviar: ${e.message}`); }
    i.commandName = 'say';
    const logged = await audit(i, {
      title: '💬 Mensagem enviada (/say)', color: 0x5865f2,
      fields: [{ name: 'Canal de destino', value: `${ch}`, inline: true }, { name: 'Mensagem', value: `[Ir para a mensagem](${msg.url})`, inline: true }],
      description: `**Conteúdo:**\n${cut(text, 3500)}`,
    });
    return i.editReply(`✅ Mensagem enviada em ${ch}.${logged ? '' : NO_AUDIT}`);
  }

  if (kind === 'embed') {
    const get = (id) => (i.fields.getTextInputValue(id) || '').trim();
    const title = get('title'); const desc = get('desc'); const color = get('color');
    const image = get('image'); const footer = get('footer');
    if (!title && !desc) return i.editReply('❌ Informe pelo menos o título ou a descrição.');
    if (color && !/^#?[0-9a-f]{6}$/i.test(color)) return i.editReply('❌ Cor inválida. Use hex, ex: `#5865F2`.');
    if (image && !/^https?:\/\/\S+$/i.test(image)) return i.editReply('❌ A imagem deve ser uma URL http(s).');
    const embed = new EmbedBuilder().setColor(color ? parseInt(color.replace('#', ''), 16) : 0x5865f2);
    if (title) embed.setTitle(title);
    if (desc) embed.setDescription(desc);
    if (image) embed.setImage(image);
    if (footer) embed.setFooter({ text: footer });
    let msg;
    try { msg = await ch.send({ embeds: [embed], allowedMentions: { parse: [] } }); } catch (e) { return i.editReply(`❌ Não consegui enviar: ${e.message}`); }
    i.commandName = 'embed';
    const logged = await audit(i, {
      title: '🧾 Embed enviado (/embed)', color: 0x5865f2,
      fields: [
        { name: 'Canal de destino', value: `${ch}`, inline: true },
        { name: 'Mensagem', value: `[Ir para a mensagem](${msg.url})`, inline: true },
        ...(title ? [{ name: 'Título', value: cut(title, 256) }] : []),
        ...(desc ? [{ name: 'Descrição', value: cut(desc, 900) }] : []),
      ],
    });
    return i.editReply(`✅ Embed enviado em ${ch}.${logged ? '' : NO_AUDIT}`);
  }
}

// ---- /lock e /unlock ----
async function lock(i, unlocking) {
  if (!hasPerm(i, P.ManageChannels)) return deny(i, 'Gerenciar Canais');
  const ch = i.options.getChannel('canal') || i.channel;
  const reason = reasonText(i.options.getString('motivo'));
  await i.deferReply({ flags: EPH });
  if (!TEXT_TYPES.includes(ch.type)) return i.editReply('❌ Só é possível trancar canais de texto.');

  const everyone = i.guild.roles.everyone;
  const cur = ch.permissionOverwrites.cache.get(everyone.id);
  const isLocked = Boolean(cur?.deny.has(P.SendMessages));
  const locks = (config.moderation.locks ||= {});

  try {
    if (!unlocking) {
      if (isLocked) return i.editReply(`❌ ${ch} já está trancado.`);
      locks[ch.id] = cur?.allow.has(P.SendMessages) ? 'allow' : 'neutral';
      saveConfig();
      // Avisa ANTES de trancar (o @everyone negado também afeta o bot, se ele não for admin)
      await ch.send({
        embeds: [new EmbedBuilder().setColor(0xed4245).setTitle('🔒 Canal trancado')
          .setDescription(`Este canal foi trancado pela moderação.\n**Motivo:** ${cut(reason, 500)}`).setTimestamp()],
      }).catch(() => {});
      await ch.permissionOverwrites.edit(everyone, { SendMessages: false }, { reason: `${reason} | /lock por ${i.user.tag}` });
    } else {
      if (!isLocked) return i.editReply(`❌ ${ch} não está trancado.`);
      const prev = locks[ch.id] === 'allow' ? true : null;
      await ch.permissionOverwrites.edit(everyone, { SendMessages: prev }, { reason: `${reason} | /unlock por ${i.user.tag}` });
      delete locks[ch.id];
      saveConfig();
      await ch.send({
        embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('🔓 Canal destrancado')
          .setDescription('Este canal foi liberado novamente.').setTimestamp()],
      }).catch(() => {});
    }
  } catch (e) {
    return i.editReply(`❌ Não consegui alterar as permissões: ${e.message}\nO bot precisa de **Gerenciar Cargos/Permissões** e das mesmas permissões que vai alterar no canal.`);
  }

  const logged = await audit(i, {
    title: unlocking ? '🔓 Canal destrancado' : '🔒 Canal trancado', color: unlocking ? 0x57f287 : 0xed4245,
    fields: [{ name: 'Canal', value: `${ch}`, inline: true }, { name: 'Motivo', value: cut(reason) }],
  });
  return i.editReply(`${unlocking ? '🔓' : '🔒'} ${ch} ${unlocking ? 'destrancado' : 'trancado'}.${logged ? '' : NO_AUDIT}`);
}

async function handleCommand(i) {
  switch (i.commandName) {
    case 'ban': return ban(i);
    case 'kick': return kick(i);
    case 'say': return say(i);
    case 'embed': return embedCmd(i);
    case 'time-out': return timeout(i);
    case 'lock': return lock(i, false);
    case 'unlock': return lock(i, true);
    default: return undefined;
  }
}

module.exports = { commands, names, handleCommand, handleModal, audit, parseDuration };

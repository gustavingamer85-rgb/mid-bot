'use strict';
const crypto = require('crypto');
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder,
  TextInputStyle, UserSelectMenuBuilder, ChannelType, PermissionFlagsBits, AttachmentBuilder, MessageFlags,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
} = require('discord.js');
const QRCode = require('qrcode');
const { config, deals, users } = require('./db');
const { getGateway, gatewayReady } = require('./gateways');
const U = require('./utils');
const profile = require('./profile');

const EPH = MessageFlags.Ephemeral;
let _client = null;
const init = (client) => { _client = client; };

// ======================================================================
// Helpers
// ======================================================================
const STATUS = {
  awaiting_accept: ['🟡', 'Aguardando aceite'],
  awaiting_payment: ['🟠', 'Aguardando pagamento'],
  paid: ['🟢', 'Pago — valor retido pelo MID'],
  dispute: ['🔴', 'Em disputa'],
  awaiting_refund_key: ['🟣', 'Aguardando chave PIX para reembolso'],
  releasing: ['⏳', 'Liberando pagamento ao vendedor'],
  refunding: ['⏳', 'Reembolsando o comprador'],
  payout_failed: ['❌', 'Falha no envio — a staff precisa agir'],
  payout_unknown: ['⚠️', 'Envio incerto — a staff precisa conferir'],
  released: ['✅', 'Concluído — vendedor pago'],
  refunded: ['↩️', 'Reembolsado ao comprador'],
  cancelled: ['⚫', 'Cancelado'],
};

const row = (...c) => new ActionRowBuilder().addComponents(...c);
const btn = (id, label, style, emoji) => {
  const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  if (emoji) b.setEmoji(emoji);
  return b;
};
const { Primary, Secondary, Success, Danger } = ButtonStyle;

// Tipos de intermediação (select do painel). extra = soma a taxa extra de contas.
const TYPES = {
  normal: { label: 'Negociação comum', description: 'Itens, serviços, dinheiro, etc.', emoji: '🤝' },
  account: { label: 'Negociação com conta', description: 'Envolve conta (taxa extra)', emoji: '🔑', extra: true },
  alt: { label: 'Alt de Robux (sem email)', description: 'Sem taxa extra de conta', emoji: '💎' },
};
const typeOf = (t) => (TYPES[t] ? t : 'normal');

const staffPing = () => (config.staffRoleId ? `<@&${config.staffRoleId}>` : '');
const currentCharge = (deal) => (deal.charges || []).at(-1) || null;

function setStatus(deal, status) {
  deal.status = status;
  deal.updatedAt = Date.now();
  deals.save();
}

async function getChannel(deal) {
  try { return await _client.channels.fetch(deal.channelId); } catch { return null; }
}

async function say(deal, payload) {
  const ch = await getChannel(deal);
  if (!ch) return null;
  return ch.send(payload).catch((e) => { console.error('[say]', e.message); return null; });
}

async function log(deal, title, desc, color = 0x5865f2) {
  if (!config.logChannelId) return;
  try {
    const ch = await _client.channels.fetch(config.logChannelId);
    await ch.send({
      embeds: [new EmbedBuilder().setTitle(`${title} • #${deal.id}`).setDescription(desc).setColor(color).setTimestamp()],
    });
  } catch (e) {
    console.error('[log]', e.message);
  }
}

function calcFees(valueCents, type = 'normal') {
  let fee = U.baseFee(valueCents, config.feeTiers);
  if (TYPES[typeOf(type)].extra) fee += Math.round((valueCents * config.accountExtraPercent) / 100);
  const feeCents = Math.min(fee, valueCents);
  let buyerFee = 0;
  let sellerFee = 0;
  if (config.feePayer === 'buyer') buyerFee = feeCents;
  else if (config.feePayer === 'seller') sellerFee = feeCents;
  else { sellerFee = Math.floor(feeCents / 2); buyerFee = feeCents - sellerFee; }
  return { feeCents, buyerPaysCents: valueCents + buyerFee, sellerGetsCents: valueCents - sellerFee };
}

// ======================================================================
// Render do painel principal do ticket
// ======================================================================
function renderDeal(deal) {
  const [emoji, label] = STATUS[deal.status] || ['❔', deal.status];
  const color = {
    paid: 0x57f287, released: 0x57f287, dispute: 0xed4245, payout_failed: 0xed4245,
    payout_unknown: 0xfee75c, cancelled: 0x4f545c, refunded: 0xeb459e,
  }[deal.status] ?? 0x5865f2;

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(`🛡️ Middleman #${deal.id}`)
    .setDescription(`**Negócio:** ${deal.description.slice(0, 1000)}`)
    .addFields(
      { name: 'Comprador', value: `<@${deal.buyerId}>`, inline: true },
      { name: 'Vendedor', value: `<@${deal.sellerId}>`, inline: true },
      { name: 'Status', value: `${emoji} ${label}`, inline: true },
      { name: 'Tipo', value: `${TYPES[typeOf(deal.type)].emoji} ${TYPES[typeOf(deal.type)].label}`, inline: true },
      { name: 'Valor do negócio', value: U.brl(deal.valueCents), inline: true },
      { name: 'Taxa do MID', value: U.brl(deal.feeCents), inline: true },
      { name: 'Comprador paga', value: U.brl(deal.buyerPaysCents), inline: true },
      { name: 'Vendedor recebe', value: U.brl(deal.sellerGetsCents), inline: true },
    )
    .setFooter({ text: 'Nunca pague fora do PIX gerado pelo bot.' })
    .setTimestamp(deal.updatedAt || Date.now());

  if (deal.sellerPixKey) {
    embed.addFields({
      name: 'PIX do vendedor',
      value: `${U.KEY_TYPE_LABEL[deal.sellerPixKey.type]} • \`${U.maskKey(deal.sellerPixKey)}\``,
      inline: true,
    });
  }

  const id = deal.id;
  const rows = [];
  const cur = currentCharge(deal);
  switch (deal.status) {
    case 'awaiting_accept':
      rows.push(row(btn(`mid:accept:${id}`, 'Aceitar negociação', Success, '✅'), btn(`mid:ask:cancel:${id}`, 'Cancelar', Danger, '✖️')));
      break;
    case 'awaiting_payment': {
      const buttons = [
        btn(`mid:check:${id}`, 'Verificar pagamento', Primary, '🔄'),
        btn(`mid:copy:${id}`, 'Copiar código PIX', Secondary, '📋'),
      ];
      if (cur && cur.state !== 'pending') buttons.push(btn(`mid:regen:${id}`, 'Gerar novo PIX', Success, '♻️'));
      buttons.push(btn(`mid:ask:cancel:${id}`, 'Cancelar', Danger, '✖️'));
      rows.push(row(...buttons));
      break;
    }
    case 'paid':
      rows.push(row(btn(`mid:ask:release:${id}`, 'Liberar pagamento', Success, '💸'), btn(`mid:ask:dispute:${id}`, 'Abrir disputa', Danger, '🚨')));
      break;
    case 'dispute':
      rows.push(row(
        btn(`mid:ask:release:${id}`, 'Liberar pagamento', Success, '💸'),
        btn(`mid:ask:srelease:${id}`, 'Staff: pagar vendedor', Primary, '🛡️'),
        btn(`mid:ask:srefund:${id}`, 'Staff: reembolsar comprador', Danger, '🛡️'),
      ));
      break;
    case 'awaiting_refund_key':
      rows.push(row(btn(`mid:refundkey:${id}`, 'Informar minha chave PIX', Success, '🔑')));
      break;
    case 'payout_failed':
    case 'payout_unknown':
      rows.push(row(
        btn(`mid:ask:retry:${id}`, 'Staff: tentar novamente', Primary, '🔁'),
        btn(`mid:ask:markdone:${id}`, 'Staff: marcar como enviado', Success, '✔️'),
      ));
      break;
    case 'released':
    case 'refunded':
      rows.push(row(btn(`mid:close:${id}`, 'Fechar ticket', Secondary, '🔒')));
      break;
    default:
  }
  return { embeds: [embed], components: rows };
}

async function refreshMain(deal) {
  try {
    const ch = await getChannel(deal);
    if (!ch || !deal.mainMessageId) return;
    const msg = await ch.messages.fetch(deal.mainMessageId);
    await msg.edit(renderDeal(deal));
  } catch (e) {
    console.error('[refreshMain]', e.message);
  }
}

// ======================================================================
// Abrir negociação (painel -> select de usuário -> modal -> canal)
// ======================================================================
/** Select do painel: escolhe o tipo e pergunta se a pessoa é comprador ou vendedor. */
async function handleStringSelect(interaction) {
  if (interaction.customId !== 'mid:type') return;
  const type = typeOf(interaction.values[0]);
  const t = TYPES[type];
  // Reedita o painel (interaction.update) para o menu voltar ao placeholder; a resposta vai por followUp
  await interaction.update(require('./config').buildPanel());
  return interaction.followUp({
    content: `${t.emoji} **${t.label}** — você é o comprador ou o vendedor?`,
    components: [row(
      btn(`mid:start:buyer:${type}`, 'Sou o comprador', Success, '🛒'),
      btn(`mid:start:seller:${type}`, 'Sou o vendedor', Primary, '💼'),
    )],
    flags: EPH,
  });
}

function startOpen(interaction, role, type) {
  type = typeOf(type);
  if (!config.enabled) return interaction.reply({ content: '⛔ O sistema de MID está desativado no momento.', flags: EPH });
  if (!gatewayReady()) return interaction.reply({ content: '⚙️ O sistema ainda está sendo configurado pela staff. Tente mais tarde.', flags: EPH });
  const who = role === 'buyer' ? 'VENDEDOR' : 'COMPRADOR';
  const menu = new UserSelectMenuBuilder()
    .setCustomId(`mid:partner:${role}:${type}`)
    .setPlaceholder(`Selecione o ${who} da negociação`)
    .setMinValues(1).setMaxValues(1);
  return interaction.reply({
    content: `Você será o **${role === 'buyer' ? 'comprador' : 'vendedor'}**. Quem é o **${who.toLowerCase()}**?`,
    components: [row(menu)],
    flags: EPH,
  });
}

function openModal(interaction, role, partnerId, type) {
  const m = new ModalBuilder().setCustomId(`mid:open:${role}:${partnerId}:${typeOf(type)}`).setTitle('Nova negociação (MID)');
  const input = (id, label, style, placeholder, required = true) => {
    const t = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required);
    if (placeholder) t.setPlaceholder(placeholder);
    return row(t);
  };
  m.addComponents(
    input('value', 'Valor do negócio (R$)', TextInputStyle.Short, `Ex: 50,00 (mín ${U.brl(config.minCents)} • máx ${U.brl(config.maxCents)})`),
    input('desc', 'O que está sendo negociado?', TextInputStyle.Paragraph, 'Descreva o produto/serviço e as condições combinadas'),
  );
  if (role === 'seller') {
    m.addComponents(
      input('pix', 'Sua chave PIX (para receber)', TextInputStyle.Short, 'CPF, CNPJ, e-mail, telefone ou chave aleatória'),
      input('pixtype', 'Tipo da chave (opcional)', TextInputStyle.Short, 'cpf, cnpj, email, telefone ou aleatoria', false),
    );
  }
  return interaction.showModal(m);
}

async function submitOpen(interaction, role, partnerId, type) {
  type = typeOf(type);
  await interaction.deferReply({ flags: EPH });
  const guild = interaction.guild;
  const fail = (msg) => interaction.editReply({ content: `❌ ${msg}` });

  if (!config.enabled || !gatewayReady()) return fail('Sistema indisponível no momento.');
  if (partnerId === interaction.user.id) return fail('Você não pode negociar consigo mesmo.');

  let partner;
  try { partner = await guild.members.fetch(partnerId); } catch { return fail('Esse usuário não está no servidor.'); }
  if (partner.user.bot) return fail('Não é possível negociar com um bot.');

  const valueCents = U.parseMoney(interaction.fields.getTextInputValue('value'));
  if (!Number.isFinite(valueCents)) return fail('Valor inválido.');
  if (valueCents < config.minCents || valueCents > config.maxCents) {
    return fail(`O valor deve ficar entre ${U.brl(config.minCents)} e ${U.brl(config.maxCents)}.`);
  }
  const fees = calcFees(valueCents, type);
  if (fees.sellerGetsCents <= 0) return fail('A taxa deixa o valor do vendedor zerado. Aumente o valor.');
  if (config.gateway === 'eclipsepay' && fees.buyerPaysCents > 100000) {
    return fail('A EclipsePay limita cada operação a R$ 1.000,00. Reduza o valor.');
  }

  const open = deals.all().filter((d) => !d.closed && d.creatorId === interaction.user.id && !['released', 'refunded', 'cancelled'].includes(d.status));
  if (open.length >= config.maxOpenDeals) return fail(`Você já tem ${open.length} negociações em aberto.`);

  let sellerPixKey = null;
  if (role === 'seller') {
    try {
      sellerPixKey = U.normalizePixKey(
        interaction.fields.getTextInputValue('pix'),
        interaction.fields.getTextInputValue('pixtype'),
      );
    } catch (e) { return fail(e.message); }
  }

  const buyerId = role === 'buyer' ? interaction.user.id : partnerId;
  const sellerId = role === 'seller' ? interaction.user.id : partnerId;

  const allow = [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles];
  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: buyerId, allow },
    { id: sellerId, allow },
    { id: interaction.client.user.id, allow: [...allow, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageMessages] },
  ];
  if (config.staffRoleId) overwrites.push({ id: config.staffRoleId, allow });

  const deal = deals.create({
    guildId: guild.id, channelId: null, creatorId: interaction.user.id, buyerId, sellerId,
    description: interaction.fields.getTextInputValue('desc').trim(),
    type, valueCents, ...fees, sellerPixKey, buyerPixKey: null, status: 'awaiting_accept', gateway: config.gateway,
  });

  let channel;
  try {
    channel = await guild.channels.create({
      name: `mid-${deal.id}`,
      type: ChannelType.GuildText,
      parent: config.ticketCategoryId || undefined,
      topic: `Middleman #${deal.id} • comprador ${buyerId} • vendedor ${sellerId}`,
      permissionOverwrites: overwrites,
    });
  } catch (e) {
    deal.closed = true; deal.status = 'cancelled'; deals.save();
    console.error('[openDeal]', e);
    return fail('Não consegui criar o canal. Verifique se o bot tem permissão de **Gerenciar Canais** (e na categoria configurada).');
  }

  deal.channelId = channel.id;
  deals.save();
  const other = role === 'buyer' ? sellerId : buyerId;
  const msg = await channel.send({
    content: `<@${buyerId}> <@${sellerId}> ${staffPing()}\n<@${other}>, **${role === 'buyer' ? 'o comprador' : 'o vendedor'}** abriu esta negociação. Confira os dados e clique em **Aceitar negociação**.`,
    ...renderDeal(deal),
  });
  deal.mainMessageId = msg.id;
  deals.save();
  await log(deal, '🆕 Negociação aberta', `Comprador <@${buyerId}> • Vendedor <@${sellerId}>\nValor: **${U.brl(valueCents)}**\n${deal.description.slice(0, 500)}`);
  return interaction.editReply({ content: `✅ Negociação criada: ${channel}` });
}

// ======================================================================
// Pagamento (cobrança PIX)
// ======================================================================
async function startPayment(deal) {
  const gwName = config.gateway;
  if (!gatewayReady(gwName)) throw new Error('Gateway não configurado.');
  const gw = getGateway(gwName);
  if (deal.buyerPaysCents > gw.limits.maxChargeCents) throw new Error(`${gw.name} limita cada operação a ${U.brl(gw.limits.maxChargeCents)}.`);

  const expiryMin = config.paymentExpiryMin;
  const ch = await gw.createCharge({
    amountCents: deal.buyerPaysCents,
    description: `MID #${deal.id}`,
    expiresInSec: expiryMin * 60,
    metadata: { dealId: deal.id },
  });

  const charge = {
    id: ch.id, gateway: gwName, brCode: ch.brCode, state: 'pending', createdAt: Date.now(),
    expiresAt: ch.expiresAt || new Date(Date.now() + expiryMin * 60000).toISOString(),
  };
  deal.charges.push(charge);
  deal.gateway = gwName;
  setStatus(deal, 'awaiting_payment');

  const png = await QRCode.toBuffer(ch.brCode, { width: 420, margin: 2 });
  const expTs = Math.floor(Date.parse(charge.expiresAt) / 1000);
  const embed = new EmbedBuilder()
    .setColor(0xfaa61a)
    .setTitle('💳 Pagamento via PIX')
    .setDescription(
      `<@${deal.buyerId}>, pague **${U.brl(deal.buyerPaysCents)}** escaneando o QR Code ou usando o PIX copia e cola.\n` +
      `⏰ Expira <t:${expTs}:R>\n\n**Copia e cola:**\n\`\`\`${ch.brCode}\`\`\``,
    )
    .setImage('attachment://pix.png')
    .setFooter({ text: 'O pagamento é detectado automaticamente.' });

  const msg = await say(deal, { embeds: [embed], files: [new AttachmentBuilder(png, { name: 'pix.png' })] });
  deal.payMessageId = msg?.id || null;
  deals.save();
  await refreshMain(deal);
  await log(deal, '💳 Cobrança gerada', `${gw.name} • ${U.brl(deal.buyerPaysCents)} • \`${ch.id}\``);
}

async function disablePayMessage(deal, text) {
  if (!deal.payMessageId) return;
  try {
    const ch = await getChannel(deal);
    const msg = await ch.messages.fetch(deal.payMessageId);
    await msg.edit({ embeds: [EmbedBuilder.from(msg.embeds[0]).setImage(null).setDescription(text).setColor(0x4f545c)], files: [], attachments: [] });
  } catch { /* mensagem pode ter sido apagada */ }
}

async function confirmPaid(deal, charge) {
  setStatus(deal, 'paid');
  deal.paidAt = Date.now();
  deals.save();
  await disablePayMessage(deal, `✅ Pagamento de **${U.brl(deal.buyerPaysCents)}** confirmado.`);
  await refreshMain(deal);
  await say(deal, {
    content: `<@${deal.buyerId}> <@${deal.sellerId}>`,
    embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('💰 Pagamento confirmado!').setDescription(
      `O valor está **retido com segurança** no MID.\n\n` +
      `• <@${deal.sellerId}>: pode **entregar** o combinado.\n` +
      `• <@${deal.buyerId}>: ao receber tudo certo, clique em **Liberar pagamento**.\n` +
      `• Algum problema? Clique em **Abrir disputa**.`,
    )],
  });
  await log(deal, '💰 Pagamento confirmado', `${U.brl(deal.buyerPaysCents)} via ${charge.gateway} • \`${charge.id}\``, 0x57f287);
}

/** Consulta a cobrança no gateway e aplica o resultado. Seguro para chamadas concorrentes. */
async function checkCharge(deal, charge) {
  if (charge.state !== 'pending') return false;
  const gw = getGateway(charge.gateway || deal.gateway);
  const r = await gw.getCharge(charge.id);
  if (charge.state !== 'pending') return false; // outra chamada já tratou durante o await

  if (r.status === 'paid') {
    if (deal.status === 'awaiting_payment') {
      charge.state = 'paid';
      deals.save();
      await confirmPaid(deal, charge);
    } else {
      charge.state = 'paid_orphan';
      deals.save();
      await say(deal, { content: `${staffPing()} ⚠️ Um pagamento (${U.brl(deal.buyerPaysCents)}) foi recebido **depois** de a negociação sair de "aguardando pagamento". Reembolso manual necessário.` });
      await log(deal, '⚠️ Pagamento órfão', `Cobrança \`${charge.id}\` paga com a negociação em **${deal.status}**. Reembolsar manualmente.`, 0xed4245);
    }
    return true;
  }

  const timedOut = Date.now() > Date.parse(charge.expiresAt) + 2 * 60 * 1000;
  if (r.status === 'expired' || r.status === 'failed' || timedOut) {
    charge.state = r.status === 'failed' ? 'failed' : 'expired';
    deals.save();
    if (deal.status === 'awaiting_payment' && currentCharge(deal) === charge) {
      await disablePayMessage(deal, '⏰ Este PIX expirou. Clique em **Gerar novo PIX** na mensagem principal.');
      await refreshMain(deal);
    }
  }
  return false;
}

// ======================================================================
// Saques (liberação / reembolso)
// ======================================================================
async function executePayout(deal, kind, actorId) {
  const retry = ['payout_failed', 'payout_unknown'].includes(deal.status);
  if (retry) kind = deal.payout?.kind;
  else if (!['paid', 'dispute', 'awaiting_refund_key'].includes(deal.status)) return '❌ Esta negociação não está em um estado que permita isso.';

  const isRelease = kind === 'release';
  const key = isRelease ? deal.sellerPixKey : deal.buyerPixKey;
  if (!key) return '❌ Chave PIX do destinatário não cadastrada.';
  const amountCents = isRelease ? deal.sellerGetsCents : deal.buyerPaysCents;

  // --- trecho síncrono: "reserva" a operação para impedir saque duplo ---
  const reuseKey = retry && deal.status === 'payout_unknown' && deal.payout?.idemKey;
  deal.payout = {
    kind, status: 'requesting', by: actorId, error: null,
    idemKey: reuseKey ? deal.payout.idemKey : crypto.randomUUID(),
    id: reuseKey ? deal.payout.id : null,
    attempts: (deal.payout?.attempts || 0) + 1,
  };
  setStatus(deal, isRelease ? 'releasing' : 'refunding');
  // ----------------------------------------------------------------------

  await refreshMain(deal);
  let res;
  try {
    res = await getGateway(deal.gateway).createPayout({
      amountCents, pixKey: key.key, pixKeyType: key.type,
      description: `MID #${deal.id} ${isRelease ? 'liberacao' : 'reembolso'}`,
      idempotencyKey: deal.payout.idemKey,
    });
  } catch (e) {
    console.error('[payout]', e.message);
    deal.payout.error = e.message;
    deal.payout.status = e.ambiguous ? 'unknown' : 'failed';
    setStatus(deal, e.ambiguous ? 'payout_unknown' : 'payout_failed');
    await refreshMain(deal);
    const warn = e.ambiguous
      ? `⚠️ Não foi possível confirmar se o saque saiu. **Confira o painel do gateway antes de tentar de novo** (na PurinCash não há proteção contra duplicidade). Se já saiu, use "marcar como enviado".`
      : `O gateway recusou o saque. Verifique saldo/chave e use "tentar novamente".`;
    await say(deal, { content: `${staffPing()} ❌ Falha ao ${isRelease ? 'pagar o vendedor' : 'reembolsar o comprador'}: \`${e.message}\`\n${warn}` });
    await log(deal, '❌ Falha no saque', `${isRelease ? 'Liberação' : 'Reembolso'} de ${U.brl(amountCents)}\n\`${e.message}\``, 0xed4245);
    return `❌ Falha no saque: ${e.message}`;
  }

  deal.payout.id = res.id;
  deal.payout.status = res.status;
  deals.save();
  await log(deal, '📤 Saque solicitado', `${isRelease ? 'Liberação ao vendedor' : 'Reembolso ao comprador'} • ${U.brl(amountCents)} • \`${res.id}\` • ${res.status}`);

  if (res.status === 'completed') await finalizePayout(deal);
  else if (res.status === 'failed') await failPayout(deal);
  else {
    await refreshMain(deal);
    await say(deal, { content: '⏳ Saque solicitado ao gateway. Assim que for confirmado, o status é atualizado automaticamente.' });
  }
  return '✅ Saque solicitado com sucesso.';
}

/** Vouch público: aviso no canal de vouchs quando o vendedor é pago. */
async function postVouch(deal) {
  if (!config.vouchChannelId || deal.vouchPosted) return;
  deal.vouchPosted = true;
  deals.save();
  try {
    const ch = await _client.channels.fetch(config.vouchChannelId);
    const ts = Math.floor(Date.now() / 1000);
    const who = (id) => (users.isHidden(id) ? '`Usuário oculto`' : `<@${id}>`);
    const container = new ContainerBuilder()
      .setAccentColor(parseInt(String(config.panel.color).replace('#', ''), 16) || 0x8a2be2)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## 🤝 — Troca de PIX completa. (${deal.payout?.manual ? 'Manual' : 'Automático'})`))
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent('> Uma troca de pix automática aconteceu, informações abaixo:'))
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `- 💲 **Valor:** ${U.brl(deal.valueCents)}\n` +
        `- 👤 **Participantes:** ${who(deal.buyerId)} e ${who(deal.sellerId)}\n` +
        `- 📅 **Horário:** <t:${ts}:f>`,
      ));
    await ch.send({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
  } catch (e) {
    deal.vouchPosted = false;
    deals.save();
    console.error('[vouch]', e.message);
  }
}

async function finalizePayout(deal) {
  const isRelease = deal.payout.kind === 'release';
  deal.payout.status = 'completed';
  if (isRelease) deal.completedAt = Date.now();
  setStatus(deal, isRelease ? 'released' : 'refunded');
  await refreshMain(deal);
  await say(deal, {
    content: `<@${deal.buyerId}> <@${deal.sellerId}>`,
    embeds: [new EmbedBuilder().setColor(isRelease ? 0x57f287 : 0xeb459e)
      .setTitle(isRelease ? '✅ Negociação concluída!' : '↩️ Reembolso efetuado')
      .setDescription(isRelease
        ? `O pagamento de **${U.brl(deal.sellerGetsCents)}** foi enviado ao vendedor. Obrigado por usar o MID!`
        : `O valor de **${U.brl(deal.buyerPaysCents)}** foi devolvido ao comprador.`)],
  });
  await log(deal, isRelease ? '✅ Concluído' : '↩️ Reembolsado', `Valor: ${U.brl(isRelease ? deal.sellerGetsCents : deal.buyerPaysCents)}`, 0x57f287);
  if (isRelease) {
    await postVouch(deal);
    await Promise.all([deal.buyerId, deal.sellerId].map((id) => profile.syncUserRoles(_client, deal.guildId, id)));
  }
}

async function failPayout(deal) {
  deal.payout.status = 'failed';
  setStatus(deal, 'payout_failed');
  await refreshMain(deal);
  await say(deal, { content: `${staffPing()} ❌ O gateway **negou/falhou** o saque. Confira saldo e chave PIX e use "tentar novamente".` });
  await log(deal, '❌ Saque negado pelo gateway', `\`${deal.payout.id}\``, 0xed4245);
}

async function checkPayout(deal) {
  if (!deal.payout?.id || !['releasing', 'refunding'].includes(deal.status)) return;
  const r = await getGateway(deal.gateway).getPayout(deal.payout.id);
  if (!['releasing', 'refunding'].includes(deal.status)) return;
  if (r.status === 'completed') await finalizePayout(deal);
  else if (r.status === 'failed') await failPayout(deal);
}

// ======================================================================
// Cancelar / fechar
// ======================================================================
async function cancelDeal(deal, reason) {
  setStatus(deal, 'cancelled');
  await refreshMain(deal);
  await disablePayMessage(deal, '⚫ Negociação cancelada.');
  await say(deal, { content: `⚫ Negociação cancelada (${reason}). Este canal será fechado em instantes.` });
  await log(deal, '⚫ Cancelada', reason, 0x4f545c);
}

async function transcript(channel) {
  const lines = [];
  let before;
  for (let i = 0; i < 10; i++) {
    const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
    if (!batch || !batch.size) break;
    for (const m of batch.values()) {
      const t = new Date(m.createdTimestamp).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
      const content = m.content || (m.embeds.length ? `[embed: ${m.embeds[0].title || ''}]` : '');
      lines.push(`[${t}] ${m.author.tag}: ${content}${m.attachments.size ? ' [anexo]' : ''}`);
    }
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  return lines.reverse().join('\n') || '(vazio)';
}

async function closeTicket(deal) {
  deal.closed = true;
  deals.save();
  const ch = await getChannel(deal);
  if (!ch) return;
  try {
    if (config.logChannelId) {
      const logCh = await _client.channels.fetch(config.logChannelId);
      const text = await transcript(ch);
      await logCh.send({
        content: `📄 Transcrição da negociação #${deal.id}`,
        files: [new AttachmentBuilder(Buffer.from(text, 'utf8'), { name: `mid-${deal.id}.txt` })],
      });
    }
  } catch (e) { console.error('[transcript]', e.message); }
  await ch.delete(`MID #${deal.id} encerrado`).catch((e) => console.error('[close]', e.message));
}

// ======================================================================
// Roteamento de interações
// ======================================================================
const isParty = (i, d) => i.user.id === d.buyerId || i.user.id === d.sellerId;
const reply = (i, content) => (i.deferred || i.replied ? i.editReply({ content }) : i.reply({ content, flags: EPH }));

const ASK_TEXT = {
  release: (d) => `Confirma **liberar ${U.brl(d.sellerGetsCents)}** ao vendedor <@${d.sellerId}>? Esta ação **não pode ser desfeita**.`,
  srelease: (d) => `🛡️ Staff: pagar **${U.brl(d.sellerGetsCents)}** ao vendedor <@${d.sellerId}>? **Irreversível.**`,
  srefund: (d) => `🛡️ Staff: reembolsar **${U.brl(d.buyerPaysCents)}** ao comprador <@${d.buyerId}>? **Irreversível.**`,
  dispute: () => 'Abrir uma **disputa**? A staff será chamada para analisar o caso.',
  cancel: () => 'Tem certeza que deseja **cancelar** esta negociação?',
  retry: () => '🛡️ Tentar enviar o saque novamente? Se for PurinCash e houver dúvida se saiu, confira o painel antes.',
  markdone: () => '🛡️ Marcar o saque como **já enviado** (concluir a negociação sem enviar nada pelo bot)?',
};

async function handleButton(interaction) {
  const parts = interaction.customId.split(':'); // mid:<action>:...
  const action = parts[1];

  if (action === 'start') return startOpen(interaction, parts[2], parts[3]);

  const isAsk = action === 'ask';
  const isDo = action === 'do';
  const act = isAsk || isDo ? parts[2] : action;
  const deal = deals.get(isAsk || isDo ? parts[3] : parts[2]);
  if (!deal || deal.closed) return reply(interaction, '❌ Negociação não encontrada ou já encerrada.');
  const staff = U.isStaff(interaction, config);

  // ---- ações simples ----
  if (!isAsk && !isDo) {
    switch (act) {
      case 'accept': {
        const partnerId = deal.creatorId === deal.buyerId ? deal.sellerId : deal.buyerId;
        if (interaction.user.id !== partnerId) return reply(interaction, '❌ Quem precisa aceitar é a outra parte da negociação.');
        if (deal.status !== 'awaiting_accept') return reply(interaction, '❌ Esta negociação já foi aceita.');
        if (!deal.sellerPixKey) {
          const m = new ModalBuilder().setCustomId(`mid:pixkey:${deal.id}`).setTitle('Sua chave PIX (vendedor)');
          m.addComponents(
            row(new TextInputBuilder().setCustomId('pix').setLabel('Chave PIX para receber').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('CPF, CNPJ, e-mail, telefone ou aleatória')),
            row(new TextInputBuilder().setCustomId('pixtype').setLabel('Tipo da chave (opcional)').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('cpf, cnpj, email, telefone ou aleatoria')),
          );
          return interaction.showModal(m);
        }
        await interaction.deferReply({ flags: EPH });
        return acceptAndCharge(interaction, deal);
      }
      case 'check': {
        if (!isParty(interaction, deal) && !staff) return reply(interaction, '❌ Apenas as partes podem fazer isso.');
        if (deal.status !== 'awaiting_payment') return reply(interaction, 'ℹ️ Não há pagamento pendente.');
        const now = Date.now();
        if (deal.lastManualCheck && now - deal.lastManualCheck < 5000) return reply(interaction, '⏳ Aguarde alguns segundos.');
        deal.lastManualCheck = now;
        await interaction.deferReply({ flags: EPH });
        let found = false;
        try {
          for (const c of deal.charges.filter((x) => x.state === 'pending')) found = (await checkCharge(deal, c)) || found;
        } catch (e) { return interaction.editReply(`❌ ${e.message}`); }
        return interaction.editReply(found ? '✅ Pagamento confirmado!' : '⏳ Ainda não identificamos o pagamento. Pode levar alguns segundos após pagar.');
      }
      case 'copy': {
        if (!isParty(interaction, deal) && !staff) return reply(interaction, '❌ Apenas as partes podem fazer isso.');
        const c = currentCharge(deal);
        if (!c || c.state !== 'pending') return reply(interaction, '⚠️ Não há PIX ativo.');
        return reply(interaction, c.brCode);
      }
      case 'regen': {
        if (!isParty(interaction, deal)) return reply(interaction, '❌ Apenas as partes podem fazer isso.');
        const c = currentCharge(deal);
        if (deal.status !== 'awaiting_payment' || (c && c.state === 'pending')) return reply(interaction, '❌ Já existe um PIX ativo.');
        await interaction.deferReply({ flags: EPH });
        try { await startPayment(deal); } catch (e) { return interaction.editReply(`❌ ${e.message}`); }
        return interaction.editReply('✅ Novo PIX gerado.');
      }
      case 'refundkey': {
        if (interaction.user.id !== deal.buyerId) return reply(interaction, '❌ Apenas o comprador pode informar a chave de reembolso.');
        if (deal.status !== 'awaiting_refund_key') return reply(interaction, '❌ Nenhum reembolso aguardando chave.');
        const m = new ModalBuilder().setCustomId(`mid:refundkey:${deal.id}`).setTitle('Chave PIX para reembolso');
        m.addComponents(
          row(new TextInputBuilder().setCustomId('pix').setLabel('Sua chave PIX').setStyle(TextInputStyle.Short).setRequired(true)),
          row(new TextInputBuilder().setCustomId('pixtype').setLabel('Tipo da chave (opcional)').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('cpf, cnpj, email, telefone ou aleatoria')),
        );
        return interaction.showModal(m);
      }
      case 'close':
        if (!isParty(interaction, deal) && !staff) return reply(interaction, '❌ Sem permissão.');
        if (!['released', 'refunded', 'cancelled'].includes(deal.status)) return reply(interaction, '❌ A negociação ainda não terminou.');
        await interaction.reply({ content: '🔒 Fechando o ticket...', flags: EPH });
        return closeTicket(deal);
      default:
        return reply(interaction, '❌ Ação desconhecida.');
    }
  }

  // ---- ação com confirmação ----
  const need = {
    release: () => (interaction.user.id === deal.buyerId ? ['paid', 'dispute'].includes(deal.status) || '❌ Não há pagamento retido para liberar.' : '❌ Apenas o **comprador** pode liberar o pagamento.'),
    dispute: () => (isParty(interaction, deal) ? deal.status === 'paid' || '❌ Só é possível abrir disputa após o pagamento (e uma única vez).' : '❌ Apenas as partes podem abrir disputa.'),
    cancel: () => (isParty(interaction, deal) || staff ? ['awaiting_accept', 'awaiting_payment'].includes(deal.status) || '❌ Após o pagamento, o cancelamento só pode ser feito pela staff (reembolso).' : '❌ Sem permissão.'),
    srelease: () => (staff ? ['paid', 'dispute'].includes(deal.status) || '❌ Estado inválido.' : '❌ Apenas a staff pode fazer isso.'),
    srefund: () => (staff ? ['paid', 'dispute'].includes(deal.status) || '❌ Estado inválido.' : '❌ Apenas a staff pode fazer isso.'),
    retry: () => (staff ? ['payout_failed', 'payout_unknown'].includes(deal.status) || '❌ Estado inválido.' : '❌ Apenas a staff pode fazer isso.'),
    markdone: () => (staff ? ['payout_failed', 'payout_unknown'].includes(deal.status) || '❌ Estado inválido.' : '❌ Apenas a staff pode fazer isso.'),
  }[act];
  if (!need) return reply(interaction, '❌ Ação desconhecida.');
  const ok = need();
  if (ok !== true) return reply(interaction, ok);

  if (isAsk) {
    return interaction.reply({
      content: ASK_TEXT[act](deal),
      components: [row(btn(`mid:do:${act}:${deal.id}`, 'Confirmar', Danger, '⚠️'))],
      flags: EPH,
    });
  }

  // isDo
  await interaction.update({ content: '⏳ Processando...', components: [] });
  const done = (msg) => interaction.editReply({ content: msg, components: [] });
  try {
    switch (act) {
      case 'release':
      case 'srelease':
        return done(await executePayout(deal, 'release', interaction.user.id));
      case 'srefund':
        if (!deal.buyerPixKey) {
          setStatus(deal, 'awaiting_refund_key');
          await refreshMain(deal);
          await say(deal, { content: `<@${deal.buyerId}> a staff decidiu **reembolsar** o valor. Clique em **Informar minha chave PIX** na mensagem principal para receber.` });
          await log(deal, '↩️ Reembolso iniciado', `Aguardando chave PIX do comprador. Por <@${interaction.user.id}>`);
          return done('✅ Pedi a chave PIX ao comprador. O reembolso sai automático quando ele informar.');
        }
        return done(await executePayout(deal, 'refund', interaction.user.id));
      case 'retry':
        return done(await executePayout(deal, deal.payout?.kind, interaction.user.id));
      case 'markdone':
        if (!['payout_failed', 'payout_unknown'].includes(deal.status)) return done('❌ Estado inválido.');
        deal.payout.manual = interaction.user.id;
        await finalizePayout(deal);
        return done('✅ Marcado como enviado.');
      case 'dispute':
        if (deal.status !== 'paid') return done('❌ Estado inválido.');
        setStatus(deal, 'dispute');
        await refreshMain(deal);
        await say(deal, { content: `${staffPing()} 🚨 <@${interaction.user.id}> abriu uma **disputa** na negociação #${deal.id}. A staff vai analisar. Apresentem provas (prints, conversas) aqui.` });
        await log(deal, '🚨 Disputa aberta', `Por <@${interaction.user.id}>`, 0xed4245);
        return done('✅ Disputa aberta. A staff foi chamada.');
      case 'cancel':
        if (!['awaiting_accept', 'awaiting_payment'].includes(deal.status)) return done('❌ Estado inválido.');
        await cancelDeal(deal, `cancelada por ${interaction.user.tag}`);
        return done('✅ Cancelada.');
      default:
        return done('❌ Ação desconhecida.');
    }
  } catch (e) {
    console.error('[do]', e);
    return done(`❌ Erro: ${e.message}`);
  }
}

async function acceptAndCharge(interaction, deal) {
  try {
    await startPayment(deal);
    await say(deal, { content: `✅ <@${interaction.user.id}> aceitou a negociação. <@${deal.buyerId}>, o PIX foi gerado abaixo.` });
    return interaction.editReply('✅ Negociação aceita!');
  } catch (e) {
    console.error('[accept]', e);
    return interaction.editReply(`❌ Não consegui gerar o PIX: ${e.message}\nTente clicar em **Aceitar negociação** novamente ou chame a staff.`);
  }
}

async function handleModal(interaction) {
  const parts = interaction.customId.split(':');
  const action = parts[1];

  if (action === 'open') return submitOpen(interaction, parts[2], parts[3], parts[4]);

  const deal = deals.get(parts[2]);
  if (!deal || deal.closed) return interaction.reply({ content: '❌ Negociação não encontrada.', flags: EPH });

  if (action === 'pixkey') {
    if (interaction.user.id !== deal.sellerId || deal.status !== 'awaiting_accept') return interaction.reply({ content: '❌ Ação inválida.', flags: EPH });
    await interaction.deferReply({ flags: EPH });
    try {
      deal.sellerPixKey = U.normalizePixKey(interaction.fields.getTextInputValue('pix'), interaction.fields.getTextInputValue('pixtype'));
      deals.save();
    } catch (e) { return interaction.editReply(`❌ ${e.message}`); }
    return acceptAndCharge(interaction, deal);
  }

  if (action === 'refundkey') {
    if (interaction.user.id !== deal.buyerId || deal.status !== 'awaiting_refund_key') return interaction.reply({ content: '❌ Ação inválida.', flags: EPH });
    await interaction.deferReply({ flags: EPH });
    try {
      deal.buyerPixKey = U.normalizePixKey(interaction.fields.getTextInputValue('pix'), interaction.fields.getTextInputValue('pixtype'));
      deals.save();
    } catch (e) { return interaction.editReply(`❌ ${e.message}`); }
    const msg = await executePayout(deal, 'refund', interaction.user.id);
    return interaction.editReply(msg);
  }
}

async function handleUserSelect(interaction) {
  const [, action, role, type] = interaction.customId.split(':');
  if (action !== 'partner') return;
  const partnerId = interaction.values[0];
  if (partnerId === interaction.user.id) return interaction.update({ content: '❌ Você não pode negociar consigo mesmo. Selecione outra pessoa.' });
  const user = interaction.users.get(partnerId);
  if (user?.bot) return interaction.update({ content: '❌ Não é possível negociar com um bot.' });
  return openModal(interaction, role, partnerId, type);
}

// ======================================================================
// Poller (verificação automática) + limpeza
// ======================================================================
let busy = false;
async function tick() {
  if (busy) return;
  busy = true;
  try {
    for (const deal of deals.all()) {
      const watchCharges = (deal.charges || []).some((c) => c.state === 'pending');
      if (deal.closed && !watchCharges) continue;
      try {
        for (const c of deal.charges || []) if (c.state === 'pending') await checkCharge(deal, c);
        if (['releasing', 'refunding'].includes(deal.status)) await checkPayout(deal);
        if (!deal.closed) await housekeeping(deal);
      } catch (e) {
        console.error(`[tick #${deal.id}]`, e.message);
      }
    }
  } finally {
    busy = false;
  }
}

async function housekeeping(deal) {
  const idle = Date.now() - (deal.updatedAt || deal.createdAt);
  const pending = (deal.charges || []).some((c) => c.state === 'pending');
  if (['awaiting_accept', 'awaiting_payment'].includes(deal.status) && !pending && idle > config.idleCancelMin * 60000) {
    await cancelDeal(deal, 'inatividade');
  } else if (deal.status === 'awaiting_accept' && idle > config.idleCancelMin * 60000) {
    await cancelDeal(deal, 'inatividade');
  } else if (deal.status === 'cancelled' && idle > 15000) {
    await closeTicket(deal);
  }
}

function startPoller() {
  setInterval(() => tick().catch((e) => console.error('[tick]', e)), 20000);
  setTimeout(() => tick().catch(() => {}), 5000);
}

// Chamado pelos webhooks
async function checkChargeById(chargeId) {
  const deal = deals.byCharge(chargeId);
  if (!deal) return;
  const charge = deal.charges.find((c) => c.id === chargeId);
  if (charge) await checkCharge(deal, charge);
}
async function checkPayoutById(payoutId) {
  const deal = deals.byPayout(payoutId);
  if (deal) await checkPayout(deal);
}

module.exports = {
  init, calcFees, renderDeal, handleButton, handleModal, handleUserSelect, handleStringSelect, TYPES,
  startPoller, checkChargeById, checkPayoutById,
};

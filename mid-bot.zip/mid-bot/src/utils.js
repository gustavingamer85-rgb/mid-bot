'use strict';
const { PermissionFlagsBits } = require('discord.js');

const brl = (cents) => (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

/** "1.500,50" | "1500.5" | "R$ 20" -> centavos (NaN se inválido) */
function parseMoney(input) {
  let s = String(input ?? '').replace(/R\$|\s/g, '');
  if (!s) return NaN;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  const n = Number(s);
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : NaN;
}

function parseNumber(input) {
  const n = Number(String(input ?? '').trim().replace('%', '').replace(',', '.'));
  return Number.isFinite(n) ? n : NaN;
}

function mask(secret) {
  if (!secret) return '❌ não configurada';
  if (secret.length <= 10) return '✅ `••••••`';
  return `✅ \`${secret.slice(0, 6)}••••${secret.slice(-4)}\``;
}

function maskKey(key) {
  const k = String(key?.key ?? key ?? '');
  if (k.length <= 6) return '•••';
  return `${k.slice(0, 3)}•••${k.slice(-3)}`;
}

const ADMIN_IDS = () =>
  (process.env.ADMIN_IDS || '').split(',').map((s) => s.trim()).filter(Boolean);

function isAdmin(interaction) {
  return (
    ADMIN_IDS().includes(interaction.user.id) ||
    Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.Administrator))
  );
}

function isStaff(interaction, config) {
  if (isAdmin(interaction)) return true;
  if (!config.staffRoleId) return false;
  return Boolean(interaction.member?.roles?.cache?.has(config.staffRoleId));
}

// ---------- Chave PIX ----------
function validCpf(d) {
  if (!/^\d{11}$/.test(d) || /^(\d)\1+$/.test(d)) return false;
  for (let t = 9; t < 11; t++) {
    let s = 0;
    for (let i = 0; i < t; i++) s += Number(d[i]) * (t + 1 - i);
    if (((s * 10) % 11) % 10 !== Number(d[t])) return false;
  }
  return true;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function hintOf(h) {
  const s = String(h || '').trim().toLowerCase();
  if (!s) return '';
  if (['cpf'].includes(s)) return 'cpf';
  if (['cnpj'].includes(s)) return 'cnpj';
  if (['email', 'e-mail'].includes(s)) return 'email';
  if (['telefone', 'celular', 'phone', 'tel'].includes(s)) return 'phone';
  if (['aleatoria', 'aleatória', 'random', 'evp', 'chave aleatoria', 'chave aleatória'].includes(s)) return 'random';
  throw new Error('Tipo de chave inválido. Use: cpf, cnpj, email, telefone ou aleatoria.');
}

/** Retorna { type, key } normalizado ou lança Error com mensagem amigável. */
function normalizePixKey(raw, typeHint) {
  const s = String(raw || '').trim();
  if (!s) throw new Error('Informe a chave PIX.');
  const hint = hintOf(typeHint);
  const digits = s.replace(/\D/g, '');

  const asPhone = () => {
    let d = digits;
    if ((d.length === 12 || d.length === 13) && d.startsWith('55')) d = d.slice(2);
    if (d.length !== 10 && d.length !== 11) throw new Error('Telefone inválido. Use DDD + número.');
    return { type: 'phone', key: `+55${d}` };
  };

  if (hint === 'email' || (!hint && s.includes('@'))) {
    if (!EMAIL.test(s)) throw new Error('E-mail inválido.');
    return { type: 'email', key: s.toLowerCase() };
  }
  if (hint === 'random' || (!hint && UUID.test(s))) {
    if (!UUID.test(s)) throw new Error('Chave aleatória inválida.');
    return { type: 'random', key: s.toLowerCase() };
  }
  if (hint === 'cpf') {
    if (!validCpf(digits)) throw new Error('CPF inválido.');
    return { type: 'cpf', key: digits };
  }
  if (hint === 'cnpj') {
    if (digits.length !== 14) throw new Error('CNPJ inválido.');
    return { type: 'cnpj', key: digits };
  }
  if (hint === 'phone') return asPhone();

  if (!s.startsWith('+') && validCpf(digits)) return { type: 'cpf', key: digits };
  if (digits.length === 14) return { type: 'cnpj', key: digits };
  try {
    return asPhone();
  } catch {
    throw new Error('Não consegui identificar a chave. Informe também o tipo (cpf, cnpj, email, telefone, aleatoria).');
  }
}

const KEY_TYPE_LABEL = { cpf: 'CPF', cnpj: 'CNPJ', email: 'E-mail', phone: 'Telefone', random: 'Aleatória' };

module.exports = {
  brl, parseMoney, parseNumber, mask, maskKey, isAdmin, isStaff,
  normalizePixKey, validCpf, KEY_TYPE_LABEL,
};

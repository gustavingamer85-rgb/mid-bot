# Bot de Middleman (MID) automático — EclipsePay + PurinCash

Bot de Discord em JavaScript (discord.js v14) que intermedeia negociações: o comprador paga via PIX, o valor fica **retido** na conta do gateway e só é enviado ao vendedor quando o comprador libera (ou a staff decide numa disputa).

## Instalação
1. Instale o **Node.js 18.17+** (recomendado 20 ou 22).
2. Na pasta do projeto: `npm install`
3. Copie `.env.example` para `.env` e preencha `DISCORD_TOKEN` e `CLIENT_ID` (`GUILD_ID` e `ADMIN_IDS` são opcionais).
4. `npm start`
5. No Discord Developer Portal, convide o bot com os escopos `bot` + `applications.commands` e as permissões **Gerenciar Canais, Ver Canais, Enviar Mensagens, Anexar Arquivos, Inserir Links, Ler Histórico**.

## Configuração (tudo pelo Discord)
Use **/config** (somente Administradores ou IDs em `ADMIN_IDS`):
- **Chaves EclipsePay / PurinCash**: cola a API key (e o webhook secret, se for usar webhook). O bot testa a chave na hora e mostra o saldo.
- **Gateway ativo**: escolhe qual gateway gera as cobranças.
- **Taxas e limites**: faixas de taxa (uma por linha, ex.: `2,50 = 1,20` ou `700 = 1,2%`), taxa extra de contas (% do valor), quem paga (comprador/vendedor/dividir), valor mín./máx.
- **Prazos e webhook**: expiração do PIX, cancelamento por inatividade, limite de negociações por usuário, URL pública.
- **Canais e cargos**: categoria dos tickets, canal de logs/transcrições, **canal de vouchs (público)**, cargo da staff.
- **Aparência do painel** (título, banner, cor, aviso) e **Enviar painel**: publica o painel *Solicitar MM* com a tabela de taxas e o menu *Selecione o tipo de intermediação* (comum / com conta / alt de Robux).

## Painel de perfil
Em **/config → Painel de perfil** escolha o canal para publicar o painel fixo com 3 botões (resposta só para quem clicou):
- **Seu perfil**: imagem com total negociado, trocas, maior transação, rank geral/mensal e emblemas (calculado das negociações concluídas).
- **Benefícios**: níveis por volume negociado e progresso até o próximo; edite em **Níveis e benefícios**.
- **Configurações**: *Esconder nome em vouchs* (o nome vira `Usuário oculto` no vouch público).
Emblemas: um por nível + Top Trader (top 10 do rank), Biggest Trader (transação ≥ R$ 500) e Old Bigger (10+ trocas e 90+ dias). Requer `npm install` (usa `@napi-rs/canvas`). Negociações concluídas antes desta versão entram nas estatísticas usando a data da última atualização.

## Cargos automáticos
Em **/config → Cargos de nível** escolha o cargo de **Trader Iniciante** e o cargo de cada nível (Bronze, Prata…). Cada membro fica com **um** cargo de rank: o do maior nível atingido.
- **Trader Iniciante**: dado a quem entra no servidor (precisa do **Server Members Intent** ligado no Developer Portal; para desligar, `MEMBERS_INTENT=false` no `.env`).
- **Níveis**: atualizados automaticamente quando uma negociação é concluída e o usuário passa do volume do nível.
- **Sincronizar todos agora**: aplica os cargos para todos que já estão no servidor.
- O cargo do bot precisa de **Gerenciar Cargos** e ficar **acima** dos cargos de nível.

## Fluxo da negociação
1. Alguém escolhe o tipo no menu do painel e clica em *Sou o comprador/vendedor*, escolhe a outra parte e informa valor + descrição (o vendedor também informa a chave PIX). Cria-se um canal privado.
2. A outra parte clica em **Aceitar** (se for o vendedor, informa a chave PIX). O bot gera o PIX (QR Code + copia e cola).
3. Pagamento detectado automaticamente → valor retido. O vendedor entrega.
4. O comprador clica em **Liberar pagamento** → o bot faz o PIX ao vendedor.
5. **Disputa**: a staff chama botões para pagar o vendedor ou reembolsar o comprador (o bot pede a chave PIX ao comprador).
6. Quando o vendedor é pago, o bot publica o vouch no canal público (*Troca de PIX completa*).
7. Ao finalizar, **Fechar ticket** gera a transcrição no canal de logs.

## Confirmação de pagamento
- Padrão: o bot confere as cobranças pendentes a cada 20 s (não precisa de URL pública).
- Opcional (mais rápido): defina `WEBHOOK_PORT` e exponha por **HTTPS** (EclipsePay exige HTTPS na porta 443; use proxy reverso/Cloudflare Tunnel):
  - EclipsePay: `https://SEU_DOMINIO/webhook/eclipsepay` — cadastre no painel, copie o *secret* para o /config e clique em "Testar" (o bot responde ao desafio).
  - PurinCash: `https://SEU_DOMINIO/webhook/purincash` — o secret fica em Dashboard → Equipe & API → Developer API. Defina a "URL pública" no /config para o bot enviar o `callbackUrl`.
- O webhook só funciona como gatilho: o bot sempre reconfirma o status na API do gateway antes de agir.

## Segurança embutida
- Trava contra saque duplo (estado reservado antes da chamada) e `Idempotency-Key` fixa por tentativa na EclipsePay.
- Falha de rede/5xx num saque → status "incerto": a staff confere o painel do gateway antes de tentar de novo.
- Pagamento que chega depois de a negociação ser cancelada gera alerta para reembolso manual.
- Chaves ficam em `data/config.json` (texto simples): proteja a pasta, não envie ao Git e use permissões restritas no servidor.

## Observações dos gateways
- **EclipsePay**: conta com verificação aprovada; a key precisa das permissões `charges:create/read` e `payouts:create/read`; limite de R$ 1.000 por operação.
- **PurinCash**: saques PIX ficam `pending` até aprovação; ative aprovação automática no painel ou o modo *turbo* (no /config). Limite padrão de 10 saques/hora e valor mínimo de saque por conta (R$ 5 por padrão).
- Taxas de saque dos gateways saem do seu saldo; ajuste a taxa do MID para cobri-las.
- Teste primeiro com chave de sandbox (`ps_test_...` na PurinCash).

## Moderação e suporte (tickets)
Em **/config → Moderação e suporte** defina: **canal de auditoria**, categoria dos tickets, canal de logs/transcrições (vazio = usa o canal de logs do MID), cargo atendente, aparência do painel, categorias (até 5, formato `emoji | nome | descrição`) e opções (tickets por usuário, avaliação, boas-vindas).

**Comandos de moderação** (cada uso é registrado no canal de auditoria):
- `/ban`, `/kick` (Banir/Expulsar Membros) — respeitam a hierarquia de cargos e avisam o usuário por DM.
- `/time-out usuario duracao [motivo]` (Castigar Membros) — ex.: `10m`, `2h`, `1d`, `1h30m` (máx. 28d); use `remover` para tirar o castigo.
- `/say [canal]` e `/embed [canal]` (Gerenciar Mensagens) — abrem um formulário; menções a @everyone/cargos só valem para quem tem essa permissão.
- `/lock [canal] [motivo]` e `/unlock [canal] [motivo]` (Gerenciar Canais) — trancam/destrancam o canal para @everyone.

**Tickets de suporte:** `/painel-ticket [canal]` (administradores) publica o painel com um botão por categoria. O usuário preenche assunto + descrição e é criado um canal privado com botões para **Assumir**, **Adicionar/Remover** pessoas e **Fechar** (com motivo). Ao fechar: transcrição em HTML no canal de logs, cópia por DM ao usuário e pedido de avaliação (1–5 ⭐). Eventos (abrir, assumir, fechar, avaliação) vão para o canal de logs. Dados em `data/tickets.json`.
O bot precisa de **Banir, Expulsar, Castigar Membros, Gerenciar Canais e Gerenciar Cargos/Permissões**. Para o texto das mensagens aparecer na transcrição, ative `MESSAGE_CONTENT_INTENT=true`.

